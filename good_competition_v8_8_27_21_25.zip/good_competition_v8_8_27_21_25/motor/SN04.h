#ifndef _SN04_H
#define _SN04_H

#include "ti_msp_dl_config.h"

uint8_t SN04_X1_GET(void);
uint8_t SN04_Y1_GET(void);
uint8_t SN04_Z1_GET(void);
#endif