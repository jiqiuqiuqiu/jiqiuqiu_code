#include "SN04.h"


uint8_t SN04_X1_GET(void)
{
	uint32_t i = 0; 
	i = DL_GPIO_readPins(SN04_X1_PORT,SN04_X1_PIN);
	if(i)
	{
		return 1; 
	}
	return 0;
}

uint8_t SN04_Y1_GET(void)
{
	uint32_t i = 0;
	i = DL_GPIO_readPins(SN04_Y1_PORT,SN04_Y1_PIN);
	if(i)
	{
		return 1;
	}
	return 0;
}

uint8_t SN04_Z1_GET(void)
{
	uint32_t i = 0;
	i = DL_GPIO_readPins(SN04_Z1_PORT,SN04_Z1_PIN);
	if(i)
	{
		return 1;
	}
	return 0;
}










