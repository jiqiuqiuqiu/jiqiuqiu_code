#include "motor.h"
#include "SN04.h"
#include "ti_msp_dl_config.h"

uint32_t Periodx = 0;
uint32_t Periody = 0;
uint32_t Periodz = 0;
// volatile uint32_t pulse = 0;
// volatile uint32_t pulse_count = 0; //全局变量来计算脉冲数
// const uint32_t pulse_set = 4000; //设定要输出的脉冲数


// volatile uint32_t pulse1 = 0;
// volatile uint32_t pulse_count1 = 0; //全局变量来计算脉冲数
// const uint32_t pulse_set1 = 5000; //设定要输出的脉冲数

// volatile uint32_t pulse_count2 = 0; //全局变量来计算脉冲数
// const uint32_t pulse_set2 = 2000; //设定要输出的脉冲数

//检测标志位的全局变量
uint8_t motorCheakMode = 0;

motor_struct motor_x;
motor_struct motor_y;
motor_struct motor_z;

//电机的中断使能
void motor_x_IRQ_Enable(void)
{
    NVIC_EnableIRQ(PWM_0_INST_INT_IRQN);
}

void motor_x_IRQ_Disable(void)
{
    NVIC_DisableIRQ(PWM_0_INST_INT_IRQN);
}


void motor_y_IRQ_Enable(void)
{
    NVIC_EnableIRQ(PWM_2_INST_INT_IRQN);
}

void motor_y_IRQ_Disable(void)
{
    NVIC_DisableIRQ(PWM_2_INST_INT_IRQN);
}


void motor_z_IRQ_Enable(void)
{
    NVIC_EnableIRQ(PWM_1_INST_INT_IRQN);
}

void motor_z_IRQ_Disable(void)
{
    NVIC_DisableIRQ(PWM_1_INST_INT_IRQN);
}

//电机定时器控制
void motorx_timer(uint8_t en)
{
    if(en  == 1)
    {
        DL_TimerG_startCounter(PWM_1_INST);
    }
    else 
    {
        DL_TimerG_stopCounter(PWM_1_INST);
    }
}

void motorz_tiemr(uint8_t en)
{
    if(en  == 1)
    {
        DL_TimerG_startCounter(PWM_0_INST);
    }

    else 
    {
        DL_TimerG_stopCounter(PWM_0_INST);
    }
}

void motory_tiemr(uint8_t en)
{
    if(en  == 1)
    {
        DL_TimerG_startCounter(PWM_2_INST);
    }

    else 
    {
        DL_TimerG_stopCounter(PWM_2_INST);
    }
}

//电机方向控制
void motorx_dir(uint8_t dir)
{
    if(dir == 1)
    {
        DL_GPIO_setPins(XYZ_PORT , XYZ_X_PIN);
    }
    else 
    {
        DL_GPIO_clearPins(XYZ_PORT , XYZ_X_PIN);
    }
}

void motorz_dir(uint8_t dir)
{
    if(dir == 1)
    {
        DL_GPIO_setPins(XYZ_PORT , XYZ_Z_PIN);
    }
    else 
    {
        DL_GPIO_clearPins(XYZ_PORT , XYZ_Z_PIN);
    }
}

void motory_dir(uint8_t dir)
{
    
    if(dir == 1)
    {
        DL_GPIO_setPins(XYZ_PORT , XYZ_Y_PIN);
    }
    else 
    {
        DL_GPIO_clearPins(XYZ_PORT , XYZ_Y_PIN);
    }
}



void motors_init(void)
{
    DL_TimerG_enableInterrupt(PWM_0_INST, DL_TIMER_IIDX_ZERO);
    DL_TimerG_enableInterrupt(PWM_2_INST, DL_TIMER_IIDX_ZERO);
    DL_TimerG_enableInterrupt(PWM_1_INST, DL_TIMER_IIDX_ZERO);
    motor_x.PWM_IRQ_Enable = motor_x_IRQ_Enable;
    motor_x.PWM_IRQ_Disable = motor_x_IRQ_Disable;
    motor_x.DirContor = motorx_dir;
    motor_x.sw = motorx_timer;
    motor_x.disp = 0;

    motor_y.PWM_IRQ_Enable = motor_y_IRQ_Enable;
    motor_y.PWM_IRQ_Disable = motor_y_IRQ_Disable;
    motor_y.DirContor = motory_dir;
    motor_y.sw = motory_tiemr;
    motor_y.disp = 0;

    motor_z.PWM_IRQ_Enable = motor_z_IRQ_Enable;
    motor_z.PWM_IRQ_Disable = motor_z_IRQ_Disable;
    motor_z.DirContor = motorz_dir;
    motor_z.sw = motorz_tiemr;
    motor_z.disp = 0;

}



void Motors_cheak(void)
{
	//__disable_irq();//不使能全局中断
	motorCheakMode = 1;//开启校验

    motor_x.sw(1);
    while (1)//x电机校验
	{	
		if(!SN04_X1_GET())
		{
            motor_x.sw(0);
			motor_x.postStep = 4.5*2000;//初始化步数，4.5cm
			// SN04_DEMO();】
            motor_x.state = IDLE;
			break;	
		}
	}
	
    motor_z.sw(1);
	while (1)//Z电机校验
	{
		if (!SN04_Z1_GET())
		{
            motor_z.sw(0);   
			motor_z.postStep = 4.5*2000;//初始化步数，4.5cm
			motor_z.state = IDLE;
			break;
		}
	}

    motor_y.sw(1);
	while (1)//y电机校验
	{
		if (!SN04_Y1_GET())
		{
           motor_y.sw(0);
			motor_y.postStep = 4.5*2000;//初始化步数，4.5cm
			motor_y.state = IDLE;
			break;
		}
	}

    motor_x.PWM_IRQ_Enable();
    motor_y.PWM_IRQ_Enable();
    motor_z.PWM_IRQ_Enable();
}




void Motor_moveOn(motor_struct * motor,uint8_t direction)
{
    motor->state = BUSY;
	motor->dir = direction;
    motor->DirContor(direction);
    motor->sw(1);
}



void Motor_move(motor_struct * motor,uint8_t direction,uint64_t disp)
{ 
	while(motor->state==BUSY)
	{


	}
	if(!disp) return ;
	if (direction == DIR_SMALL_NUM)
	{
		
		motor->targetPostStep = motor->postStep - disp;
	}
	else if (direction == DIR_BIG_NUM) 
	{
		motor->targetPostStep = motor->postStep + disp;
	}
	motor->dir = direction;
	Motor_moveOn(motor,direction);
}




void motor_MoveCM(motor_struct  * motor,float x)
{
	if(x >= 0)
		Motor_move(motor,1,(uint64_t)(x*2000));
	else
		Motor_move(motor,0,(uint64_t)(fabs(x)*2000));
	
}

uint8_t motor_PostMoveStart(float x,float y,float z)
{
		if(motor_x.state == BUSY)
		{
			return ERROR;
		}
		if(motor_y.state == BUSY)
		{
			return ERROR;
		}
		if(motor_z.state == BUSY)
		{
			return ERROR;
		}
		//目标步数
		uint64_t targetx = x * 2000;
 		uint64_t targety = y * 2000;
		uint64_t targetz = z * 2000;
		
		uint8_t dir = ((targetx>=motor_x.postStep)?DIR_BIG_NUM:DIR_SMALL_NUM);
		if (dir)
			Motor_move(&motor_x,dir,targetx - motor_x.postStep);
		else
			Motor_move(&motor_x,dir,motor_x.postStep-targetx);
		
		dir = ((targety>=motor_y.postStep)?DIR_BIG_NUM:DIR_SMALL_NUM);
		if (dir)
			Motor_move(&motor_y,dir,targety - motor_y.postStep);
		else
			Motor_move(&motor_y,dir,motor_y.postStep-targety);
		
		dir = ((targetz>=motor_z.postStep)?DIR_BIG_NUM:DIR_SMALL_NUM);
		if (dir)
			Motor_move(&motor_z,dir,targetz - motor_z.postStep);
		else
			Motor_move(&motor_z,dir,motor_z.postStep-targetz);

		return SUCCESS;
}



void PWM_0_INST_IRQHandler(void)
{
    if(DL_TimerG_getEnabledInterruptStatus(PWM_0_INST,DL_TIMER_IIDX_ZERO))//获取定时器0的中断
    {
       	if (motor_z.dir == DIR_SMALL_NUM)
        {
            motor_z.postStep--;
            if (motor_z.postStep == motor_z.targetPostStep)
			{
				motor_z.sw(0);
				motor_z.state = IDLE;
			}	
        }
        else 
        {
            motor_z.postStep++;
			if (motor_z.postStep == motor_z.targetPostStep)
			{
				motor_z.sw(0);
				motor_z.state = IDLE;
			}
        }
        DL_TimerG_clearInterruptStatus(PWM_0_INST,DL_TIMER_IIDX_ZERO);//清除定时器0中断
    }   
}

void PWM_1_INST_IRQHandler(void)
{
    if(DL_TimerG_getEnabledInterruptStatus(PWM_1_INST,DL_TIMER_IIDX_ZERO))//获取定时器0的中断
    {
        if (motor_x.dir == DIR_SMALL_NUM)
        {
            motor_x.postStep--;
            if (motor_x.postStep == motor_x.targetPostStep)
			{
				motor_x.sw(0);
				motor_x.state = IDLE;
			}	
        }
        else 
        {
            motor_x.postStep++;
			if (motor_x.postStep == motor_x.targetPostStep)
			{
				motor_x.sw(0);
				motor_x.state = IDLE;
			}
        }
        DL_TimerG_clearInterruptStatus(PWM_1_INST,DL_TIMER_IIDX_ZERO);//清除定时器0中断
    }   
}

void PWM_2_INST_IRQHandler(void)
{
    if(DL_TimerA_getEnabledInterruptStatus(PWM_2_INST,DL_TIMER_IIDX_ZERO))//获取定时器0的中断
    {
        if (motor_y.dir == DIR_SMALL_NUM)
        {
            motor_y.postStep--;
            if (motor_y.postStep == motor_y.targetPostStep)
			{
				motor_y.sw(0);
				motor_y.state = IDLE;
			}	
        }
        else 
        {
            motor_y.postStep++;
			if (motor_y.postStep == motor_y.targetPostStep)
			{
				motor_y.sw(0);
				motor_y.state = IDLE;
			}
        }
        DL_TimerA_clearInterruptStatus(PWM_2_INST,DL_TIMER_IIDX_ZERO);//清除定时器0中断
    }   
}

//检测电机状态
uint8_t  motor_PostMoveGetState(void)
{
		if(motor_x.state == NOT_RESET)
		{
			return NOT_RESET;
		}
		if(motor_y.state == NOT_RESET)
		{
			return NOT_RESET;
		}
		if(motor_z.state == NOT_RESET)
		{
			return NOT_RESET;
		}
		if(motor_x.state == BUSY)
		{
			return BUSY;
		}
		if(motor_y.state == BUSY)
		{
			return BUSY;
		}
		if(motor_z.state == BUSY)
		{
			return BUSY;
		}
		return IDLE;
	
}

//电机暂停运动
void Motorx_movePause(void)
{
	if(motor_x.state == BUSY)
	{
		DL_TimerG_stopCounter(PWM_1_INST);
	}
}

void Motory_movePause(void)
{
	if(motor_y.state == BUSY)
	{
		DL_TimerA_stopCounter(PWM_2_INST);
	}
}

void Motorz_movePause(void)
{
	if(motor_z.state == BUSY)
	{
		DL_TimerG_stopCounter(PWM_0_INST);
	}
}

//电机PWM调速
void PWMX_SetFrequency(uint32_t Freq)
{
	Periodx = CPUCLK_FREQ/32/Freq;
	DL_TimerG_setLoadValue(PWM_1_INST, Periodx);
}

void PWMY_SetFrequency(uint32_t Freq)
{
	Periody = CPUCLK_FREQ/32/Freq;
	DL_TimerA_setLoadValue(PWM_2_INST, Periody);
}

void PWMZ_SetFrequency(uint32_t Freq)
{
	Periodz = CPUCLK_FREQ/32/Freq;
	DL_TimerG_setLoadValue(PWM_0_INST, Periodz);
}

void  motor_speed(MachineSpeed Speed)
{
	switch(Speed)
	{
		case LOW:
			PWMX_SetFrequency(1000);//x
			PWMY_SetFrequency(800);//y
			PWMZ_SetFrequency(1000);//z
			break;
		case MEDIUM:
			PWMX_SetFrequency(1500);//x
			PWMY_SetFrequency(1000);//y
			PWMZ_SetFrequency(1500);//z
			break;
		case HIGH:
			PWMX_SetFrequency(1900);//x
			PWMY_SetFrequency(1200);//y
			PWMZ_SetFrequency(1900);//z
			break;
	}
}





