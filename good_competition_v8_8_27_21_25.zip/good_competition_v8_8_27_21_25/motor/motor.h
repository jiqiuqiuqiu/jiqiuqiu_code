#ifndef _MOTOR_H_
#define _MOTOR_H_

#include "stdint.h"

typedef struct MOTOR_STRUCT
{	

	uint64_t postStep;//电机所能移动的最大脉冲数
	uint64_t targetPostStep;//目标步数的脉冲数
	uint64_t disp;      //达到目标位置需要移动的步数PWM
	uint16_t fre;//频率速度
	uint8_t dir;//方向
	uint8_t state;//状态
	uint8_t direction;
    void (*PWM_IRQ_Enable)(void);
    void (*PWM_IRQ_Disable)(void);
    void (*DirContor)(uint8_t dir);
    void (*sw)(uint8_t en);
}motor_struct;


//方向标志位,dir
#define FORWARD 1
#define RETREAT 2

//direction，控制方向引脚
#define DIR_SMALL_NUM 0		//顺时针
#define DIR_BIG_NUM 1		//逆时针
typedef enum 
{
	IDLE = 0,//空闲
	BUSY = 1,//繁忙
	NOT_RESET = 2 //未复位
}MOTOR_START;

typedef enum {
	ERROR = 0, 
	SUCCESS = !ERROR
} ErrStatus;

//调速
typedef enum{
	LOW = 0,
	MEDIUM,
	HIGH,
}MachineSpeed;

extern motor_struct motor_x;
extern motor_struct motor_y;
extern motor_struct motor_z;

void motors_init(void);

void Motors_cheak(void);
void Motor_move(motor_struct * motor,uint8_t direction,uint64_t disp);
uint8_t motor_PostMoveStart(float x,float y,float z);
uint8_t  motor_PostMoveGetState(void);
void Motorx_movePause(void);
void Motory_movePause(void);
void Motorz_movePause(void);
void motor_speed(MachineSpeed Speed);
#define MOTOR_POSTMOVE_REST_START() motor_PostMoveStart(15,8,10) // 复位点

void PWMX_SetFrequency(uint32_t Freq);
void PWMY_SetFrequency(uint32_t Freq);
void PWMZ_SetFrequency(uint32_t Freq);

#endif


