#include "ti_msp_dl_config.h"
#include "motor.h"
#include "SN04.h"
#include "UART0.h"
#include "UART_redirect.h"
#include "pe_switch.h"
#include "screwdriverMotor_RZ7899.h"
#include "MCTM0.h"
#include "GPTM0.h"
#include "upperComputer.h"
#include "Conveyor.h"
#include "application.h"
#include "ExtendTimer.h"
#include "UART1.h"
#include "UART2.h"
#include "BFTM0.h"
#include "RingBuffer.h"
#include "NFC.h" 



// int main(void)
// {
  
//     static ETimer_FlagTypeDef ETimer_500mSFlag;

//     SYSCFG_DL_init();
//     //GCTM0_Init();
    
//     init();
    
//     ScrewMotorClockwiseStart();
//     //MCTM0_PB9_setduty(0.5);
//     //ScrewMotorStop();
//     //PWMNumber = 57;
//     //Etimer_FlagStart(&ETimer_500mSFlag, 500);

//     // while(1)
//     // {
//     //   if(Etimer_GetFlag(&ETimer_500mSFlag))
//     //   {
//     //     if(PWMNumber <= 20)
//     //     {
//     //         ScrewMotorStop();
//     //         break;
//     //     }
//     //   }

//     // }      
    
//     while(1)
//     {
//         printf("%d\r\n",PWMNumber);
//     }
// }



int main(void)
{
  SYSCFG_DL_init();

  motor_speed(HIGH);
  scrediver_speed_state = SPEED_MEDIUM;

  init();

  while(1)
  {
     Etimer_Taskloop();
	   run();
  }
}

// int main(void)
// {
//   	SYSCFG_DL_init();
    
//     // ScrewMotor_Init();
//     // // ScrewMotor_Init();
//     // // ScrewMotor_test();
//     // while(1)
//     // {
//     //     // GPTM0_test();
//     // }

//     // motor_PostMoveStart(15,8,10);

//     //init();
//     //USART1_Configuration();
//     //BFTM0_Configuration();

//    init();
//     //motor_speed(HIGH);

//     while (1)
//     {
    
//       //TurnScrew();
//       Etimer_Taskloop();
// 	    run();
//     }
// }


// USART1_Configuration();
    // uint8_t buf = 0;

 // if (RingBuffer_PopOneData(&RingBuffer_RX1,&buf) == BUF_OK) 
        // {
        //     printf("%x\r\n",buf);
        // }

        // printf("%u\r\n",PE_SWITCH_GET());


// void TIMER_0_INST_IRQHandler(void)
// {
//     if(DL_TimerG_getEnabledInterruptStatus(TIMER_0_INST,DL_TIMER_IIDX_ZERO))//获取定时器0的中断
//     {  
//         DL_TimerG_clearInterruptStatus(TIMER_0_INST,DL_TIMER_IIDX_ZERO);//清除定时器0中断
//         //pulse_count++;
//         pulse++;
//         //pulse1++;
//         if(pulse == pulse_set)
//         {
//             DL_TimerG_stopCounter(PWM_0_INST);
//         }
//         // if(pulse1 == pulse_set1)
//         // {
//         //     DL_TimerG_stopCounter(PWM_1_INST);
//         // }
//         // if(pulse_count==10)
//         // {
//         //     DL_TimerG_stopCounter(PWM_0_INST);
//         // }
//         // if(pulse_count==20)
//         // {
//         //     DL_TimerG_stopCounter(PWM_1_INST);
//         // }
//     }   
// }


// void PWM_1_INST_IRQHandler(void)
// {
//     if(DL_TimerG_getEnabledInterruptStatus(PWM_1_INST,DL_TIMER_IIDX_ZERO))//获取定时器0的中断
//     {
//         pulse_count1++;//输出脉冲
//         if(pulse_count1>=pulse_set1)
//         {
//             DL_TimerG_stopCounter(PWM_1_INST);//停止计数
//         }
//         DL_TimerG_clearInterruptStatus(PWM_1_INST,DL_TIMER_IIDX_ZERO);//清除定时器0中断
//     }   
// }
