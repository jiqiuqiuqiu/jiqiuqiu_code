#include "application.h"
#include "ExtendTimer.h"
#include "motor.h"
#include "queue.h"
#include "UART1.h"
#include "ti_msp_dl_config.h"
#include "CRC.h"
#include "upperComputer.h"
#include "screwdriverMotor_RZ7899.h"
#include "pe_switch.h"
#include "Conveyor.h"
#include "DataConverter.h"
#include "UART0.h"
#include "NFC.h"
#include "SN04.h"
#include "key.h"
#include "system.h"
#include "UART_redirect.h"
#include "RTC.h"
#include "BFTM0.h"

systemStateEnum sysState = SYSTEM_LOCK;
uint32_t AutoModeCount=0;
static struct 
{
	uint8_t num;
	uint16_t post_x[50];
	uint16_t post_y[50];
}screwHoleDat;
DevParamTypedef DevParam;


// 应用初始化
void init(void)
{
	UART0_Configuration();
	nfc_Init();
	USART1_Configuration();
    GCTM0_Init();
	//RTC_Configuration();
    //SN04_Init();
	motors_init();
	ScrewMotor_Init();
    //PESwitch_Init();
	BFTM0_Configuration();
	conveyor_Init();
	//key_GPIOConfig();
	GPTM0_TIMER_0_Init();

    DevParam.cameraRealityL = CAMERA_REALITY_L_CM;
	DevParam.cameraRealityLOffset = CAMERA_REALITY_L_OFFSET_CM;
	DevParam.cameraRealityW = CAMERA_REALITY_W_CM;
	DevParam.cameraRealityWOffset = CAMERA_REALITY_W_OFFSET_CM;
	DevParam.pixel_L = CAMERA_PIXEL_L;
	DevParam.pixel_W = CAMERA_PIXEL_W;

    //ScrewMotor_test();
    //设置电机的初始计数值和重装载值，由于所有的定时器都是从零开始计数的，所以这里先暂时不用
	// DL_Timer_setTimerCount(QEI_0_INST,8000);
	// DL_Timer_setLoadValue(QEI_0_INST, 8000);


	// DL_Timer_setTimerCount(QEI_0_INST,30000);
	// TurnScrew();
	// while (1)
	// {
	// 	GPTM0_GET_CNT();
	// 	if (get_QEI_count() < 20000) 
	// 	{
			
	// 		ScrewMotorStop();
	// 		break;
	// 	}
	// }
	// printf("OK1\r\n");

	// DL_Timer_setTimerCount(QEI_0_INST,30000);
	// TurnScrew();
	// while (1)
	// {
	// 	GPTM0_GET_CNT();
	// 	if (get_QEI_count() < 10000) 
	// 	{
			
	// 		ScrewMotorStop();
	// 		break;
	// 	}
	// }
	// printf("OK2\r\n");

	conveyor_stop();

	
    motors_init();

    

	 #if AI_CAMERA_TEST == 1
	 Motors_cheak();

	if(MOTOR_POSTMOVE_REST_START() == SUCCESS)//复位
	{

	}
	while(motor_PostMoveGetState() == BUSY)
		;
		AiTightenScrewTask(TASK_INIT);
	#endif
}

//主循环run
void run()
{	
	//uint8_t chr;
	computerDataProcessing();
	#if AI_CAMERA_TEST == 0
	switch(sysState)
	{
		case SYSTEM_LOCK:
			if (nfc_dataDispose() == NFC_CAROK) 
			{
				sysState = SYSTEM_REST;
			}
			
		break;
		case SYSTEM_REST:
		    Motors_cheak();
			sysState = SYSTEM_RUN_AUTO;

		break;
		case SYSTEM_STANDBY:
		
		break;

		case SYSTEM_RUN_AUTO:
			ScrewMachineMovement();
		break;

		default:

		break;
	
	}	
		
		
		
		
	#else 
		AiTightenScrewTask(TASK_RUN);
	#endif
	//GPTM0_GET_CNT();


	// if(RingBuffer_PopOneData(&RingBuffer_RX1,&chr) == BUF_OK) 
	// {
	// 	printf("%x\r\n",chr);
	// }
	
}

/**
 * @brief 抓螺丝
 * @return 0 完成 1运行中
 */
uint8_t pickScrewTask(TaskState taskState)
{
	static uint8_t stepFlag = 0;//功能步骤标志位
	if(taskState == TASK_INIT)
	{
		stepFlag = 0;

		
	}
	if(stepFlag == 0)
	{
			
		if(motor_PostMoveGetState() == IDLE)
		{
			//elog_d("app","抓螺丝");
			motor_PostMoveStart(19,10,6);
			stepFlag = 1;
		}

	}
	else if(stepFlag == 1)
	{
		if(motor_PostMoveGetState() == IDLE)
		{
			motor_PostMoveStart(19,5,6);
			stepFlag = 2;
		}
	}
	else if(stepFlag == 2)
	{
		if(motor_PostMoveGetState() == IDLE)
		{
			motor_PostMoveStart(19,10,6);
			stepFlag = 3;
		}
	}
	else if(stepFlag == 3)
	{
		if(motor_PostMoveGetState() == IDLE)
		{
			stepFlag = 0;
			return 0;
		}
	}
	return 1;
}

/**
 * @brief ai处理控制任务
 * @param taskState 
 * @return 
 */
uint8_t AiTightenScrewTask(TaskState taskState)
{
	//static ETimer_FlagTypeDef ETimer_3SFlag;
	static ETimer_FlagTypeDef ETimer_15SFlag;
	static ETimer_FlagTypeDef ETimer_1SFlag;
	static ETimer_FlagTypeDef ETimer_500msFlag;
	static uint16_t post_x = 0;
	static uint16_t post_y = 0;
	static uint16_t stepFlag = 0;
	static float x_CM;
	static uint8_t  screwHoleNum = 0;
	static float y_CM;
	static float X_ADD_CM;
	static float Y_ADD_CM;

	if(taskState == TASK_INIT) 
	{
		Etimer_FlagStart(&ETimer_1SFlag, 1000);
		stepFlag = 0;
		return 0;
	}

	if (stepFlag == 0)
	{
		if (Etimer_GetFlag(&ETimer_1SFlag)) 
		{
			Etimer_FlagStop(&ETimer_1SFlag);
			upperComputer_AI_startRecog();	//发送开始识别指令数据		
			
			stepFlag = 1;
		}
		//elog_d("app","发送识别指令数据");
	
	}
	else if(stepFlag == 1) 
	{	
		if(screwHoleDat.num > 0)
		{
			stepFlag = 2;
		}
	}
	else if (stepFlag == 2) 
	{
		if(screwHoleDat.num > 0)//说明有螺丝孔
		{
			screwHoleNum = screwHoleDat.num;
			screwHoleDat.num = 0;
			stepFlag = 3;
		}
	}
	else if (stepFlag == 3) 
	{
		static uint8_t i = 0;
		if(screwHoleNum > i)
		{
			post_x = screwHoleDat.post_x[i];//像素x
			post_y = screwHoleDat.post_y[i];//像素y

			if(post_x > 640 && post_y < 360)
			{
				X_ADD_CM = X_1_CM;
				Y_ADD_CM = Y_1_CM;
			}			

			else if(post_x < 640 && post_y < 360)
			{
				X_ADD_CM = X_2_CM;
				Y_ADD_CM = Y_2_CM;
			}

			else if(post_x < 640 && post_y > 360)
			{
				X_ADD_CM = X_3_CM;
				Y_ADD_CM = Y_3_CM;
			}

			else if(post_x > 640 && post_y > 360)
			{
				X_ADD_CM = X_4_CM;
				Y_ADD_CM = Y_4_CM;
			}

			x_CM = (float)post_x*(DevParam.cameraRealityL/DevParam.pixel_L) + X_ADD_CM;//转化成实际x
			y_CM = (float)(DevParam.pixel_W - post_y)*(DevParam.cameraRealityW/DevParam.pixel_W) + Y_ADD_CM;//转化成实际y

			//printf("x:%f y:%f\r\n",x_CM,y_CM);
			
			i++;
			stepFlag = 4;
		}
		else
		{
			i = 0;
			stepFlag = 9;
		}
	}
	else if (stepFlag == 4) 
	{
		//抓螺丝
		#if PICKSCREW == 1
		if(pickScrewTask(TASK_RUN) == 0)
		{
		#endif
		if(motor_PostMoveGetState() == IDLE)
		{
			if(motor_PostMoveStart((float)y_CM+DevParam.cameraRealityWOffset,(float)10,x_CM+DevParam.cameraRealityLOffset) == SUCCESS)
			{
				stepFlag = 5;  
			}
		}
		
		#if PICKSCREW == 1
		}
		#endif

	}
	else if(stepFlag == 5)
	{
		if(motor_PostMoveGetState() == IDLE)//到达指定位置
		{
			stepFlag = 6;
			#if ADJUSTMENT_PARAMETETR == 1
			if(motor_PostMoveStart((float)y_CM+DevParam.cameraRealityWOffset,(float)5.35,x_CM+DevParam.cameraRealityLOffset) == SUCCESS)//旋转
			{
				
			#endif
			
			#if ADJUSTMENT_PARAMETETR == 1
			}
			#endif
		}
	}
	else if(stepFlag == 6)
	{
		if(motor_PostMoveGetState() == IDLE)
		{
			DL_Timer_setTimerCount(QEI_0_INST,50000);
			TurnScrew();
			Etimer_FlagStart(&ETimer_15SFlag, 12000);
			Etimer_FlagStart(&ETimer_500msFlag, 500);
			stepFlag = 7;
		}
	}
	else if(stepFlag == 7)
	{
		if(Etimer_GetFlag(&ETimer_500msFlag))
      	{
			if(Etimer_GetFlag(&ETimer_15SFlag) || PWMNumber < 28)
			{
				ScrewMotorStop();
				Etimer_FlagStop(&ETimer_15SFlag);
				if(motor_PostMoveStart((float)y_CM+DevParam.cameraRealityWOffset,(float)10,x_CM+DevParam.cameraRealityLOffset) == SUCCESS)//
					stepFlag = 8;
			}	
      	}
	}
	else if (stepFlag == 8)
	{
		if(motor_PostMoveGetState() == IDLE)
		{	
			stepFlag = 3; 
		}
	}
	else if(stepFlag == 9)
	{
		if(motor_PostMoveGetState() == IDLE)
		{
			if(MOTOR_POSTMOVE_REST_START() == SUCCESS)//复位
			{
				stepFlag = 10;
			}
		}
	}

	else if(stepFlag == 10)
	{
		if(motor_PostMoveGetState() == IDLE)
		{
			stepFlag = 0;
			AiTightenScrewTask(TASK_INIT);
			return 0;
		}
	}
	return 1;

}



void ScrewMachineMovement(void)
{
	static  ETimer_FlagTypeDef  ETimer_PE1SWaitFlag = {0};
	static uint8_t runFlag = 0;
	if(runFlag == 0)
	{	

		//复位
		if(MOTOR_POSTMOVE_REST_START() == SUCCESS)//复位
		{
			runFlag = 1;	
		}
		
	}
	else if(runFlag == 1)
	{
		if(motor_PostMoveGetState() == IDLE)//等待复位完成
		{
			//打开传送带
			conveyor_start();
			runFlag = 2;
		}
	}
	else  if (runFlag == 2) 
	{
		
		if(PE_SWITCH_GET())//检测到物品
		{	
			if(PE_SWITCH_GET())
			{
				conveyor_stop();
				Etimer_FlagStart(&ETimer_PE1SWaitFlag, 1000);
				runFlag = 3;
			}
		}
	}
	else if (runFlag == 3) 
	{
		bool PE1SWaitFlag =  Etimer_GetFlag(&ETimer_PE1SWaitFlag);
		if(PE1SWaitFlag)
		{
			Etimer_FlagStop(&ETimer_PE1SWaitFlag);
			if (PE_SWITCH_GET()) 
			{
				upperComputer_AI_startRecog();
				runFlag = 4;	
			}
			else 
			{
				runFlag = 1;
			}
	
		}
	}
	else if (runFlag == 4)
	{
		AiTightenScrewTask(TASK_INIT);
		runFlag = 5;
	}
	else if (runFlag == 5) 
	{
		if (AiTightenScrewTask(TASK_RUN) == 0) 
		{
			runFlag = 6;
		}
	}
	else if (runFlag == 6) 
	{
		conveyor_start();
		if (!PE_SWITCH_GET()) 
		{
			
			runFlag = 0;
			AutoModeCount++;
			upperComputer_SendCount(AutoModeCount);
				
	
			
		}
	}

}



/**
* @brief 串口处理
*								帧头   	命令 	数据个数										校验位
*	test data : A9 9A 		02 		04			02 	02 	25 	03 		8a 		FF
*/
void computerDataProcessing()
{
	static uint8_t runFlag = 0;

	static uint8_t buffer[140] = {0}; //buffer[0] 存储 命令 buffer[1] 存储数据长度 buffer[2]开始存储数据
	static uint8_t CRCAndFrameEnd[2];

	if(runFlag == 0)
	{
		if(RingBuffer_PopOneData(&RingBuffer_RX1,&buffer[HMI_FRAME_HEADER_H]) == BUF_OK) 
		{
			//printf("frameHeader[0] = %x",buffer[HMI_FRAME_HEADER_H]);
			if(buffer[0] == 0xA8)//帧头第一个字节
			{	
				runFlag = 1;
				//DL_UART_transmitDataBlocking(UART_1_INST,6);//UART1 115200
			}
		}
	}
	else if(runFlag == 1)
	{
			if(RingBuffer_PopOneData(&RingBuffer_RX1,&buffer[HMI_FRAME_HEADER_L]) == BUF_OK)//帧头第二个字节
			{
				//printf("frameHeader[0] = %x",buffer[HMI_FRAME_HEADER_L]);
				if(buffer[1] == 0x8A)//判断帧头的第二个字节
				{
					runFlag = 2;
					//DL_UART_transmitDataBlocking(UART_1_INST,6);//UART1 115200
				}
				else
				{
					runFlag = 0;//如果不是，则回到判断帧头的第一个字节
				}
			}
	}
	
	else if(runFlag == 2)
	{
	
			if(RingBuffer_PopOneData(&RingBuffer_RX1,&buffer[HMI_CMD]) == BUF_OK)//命令
			{
				//printf("cmd = 0x%x",buffer[HMI_CMD]);
				runFlag = 3;
				//DL_UART_transmitDataBlocking(UART_1_INST,6);//UART1 115200
			}
	}
	
	else if(runFlag == 3)
	{
		
		if(RingBuffer_PopOneData(&RingBuffer_RX1,&buffer[HMI_DATA_LEN]) == BUF_OK)//获取数据长度
		{
			//printf("数据长度：%u",buffer[HMI_DATA_LEN]);
			//printf("数据量：%u",RingBuffer_Count(&RingBuffer_RX1));

			runFlag = 4;
			//DL_UART_transmitDataBlocking(UART_1_INST,6);//UART1 115200
		}
	}
	

	else if(runFlag == 4)
	{
		if(RingBuffer_PopArrayData(&RingBuffer_RX1,&buffer[HMI_DATA],buffer[HMI_DATA_LEN]) == BUF_OK)//接收数据  
		{
			//printf("数据获取成功");
			for(uint8_t i = HMI_DATA;i < buffer[HMI_DATA_LEN];i++)
			{
				//printf("%u",buffer[i]);
			}
			runFlag = 5;
			//DL_UART_transmitDataBlocking(UART_1_INST,7);//UART1 115200
		}
		else//如果数据量不够就继续等待接收
		{
			//printf("数据量不够");
			//printf("数据量：%u",RingBuffer_Count(&RingBuffer_RX1));
		
		}
	}
	
	else if(runFlag == 5)
	{
		
		#if (HMI_DATA_CRC == 1)
		
		//DL_UART_transmitDataBlocking(UART_1_INST,1);//UART1 115200
		
		if(RingBuffer_PopArrayData(&RingBuffer_RX1,CRCAndFrameEnd,2) == BUF_OK)//获取接收帧校验位和帧尾
		{
			//DL_UART_transmitDataBlocking(UART_1_INST,9);//UART1 115200
			if(CRCAndFrameEnd[1] == 0xFF)//接收到帧尾
			{
				/*校验代码*/
				uint8_t ucrc = 0;
				ucrc = crc8(&buffer[HMI_CMD],buffer[3]+2,crc_8);
				//printf("\n%x\n",ucrc);
				
				//DL_UART_transmitDataBlocking(UART_1_INST,8);//UART1 115200	
				if(ucrc == CRCAndFrameEnd[0])//校验成功 数据完整
				{
					//printf("crc校验 OK");
					runFlag = 6;
					//DL_UART_transmitDataBlocking(UART_1_INST,7);//UART1 115200		
				}
				else//数据不完整
				{
					//printf("数据不完整 error");
					runFlag = 0;
					//向上位机重新发送的指令	
				}
			}
		}
		
		#else
			
		if(RingBuffer_PopArrayData(&RingBuffer_RX1,CRCAndFrameEnd,1) == BUF_OK)//获取接收帧尾
		{
			if(CRCAndFrameEnd[0] == 0xFF)//接收到帧尾
			{
				runFlag = 6;
			}
		
		}
		#endif
	}
	/************* 处理 数据 ************/
	else if(runFlag == 6)
	{
		switch(buffer[2])
		{
			case 1:
			{
				screwHoleDat.num = buffer[3]/4;//数据组数
				for(uint8_t i = 0;i<screwHoleDat.num;i++)
				{
						screwHoleDat.post_x[i] = (((uint16_t)buffer[i*4+4])<<8)|buffer[i*4+5];
						screwHoleDat.post_y[i] = (((uint16_t)buffer[i*4+6])<<8)|buffer[i*4+7];
							
						//printf("X:%u,Y:%u",screwHoleDat.post_x[i],screwHoleDat.post_y[i]);
				}	

				break;
			}
			case CMD_PIXEL_L:
			{
				
				DevParam.pixel_L = (uint16_t)buffer[4]<<8|buffer[5];
				printf("pixel_H:%u",DevParam.pixel_L);
				
				break;
			}
			case CMD_PIXEL_W:
			{
				
				DevParam.pixel_W = (uint16_t)buffer[4]<<8|buffer[5];
				printf("pixel_H:%u",DevParam.pixel_W);
				
				break;
			}
			case CMD_CAMERA_REALITY_L_CM:
			{
			
				DevParam.cameraRealityL = 	Uint4ToFloat(&buffer[HMI_DATA]);;
				printf("cameraRealityL:%f",DevParam.cameraRealityL);
				
				break;
			}
		
			case CMD_CAMERA_REALITY_W_CM:
			{
				DevParam.cameraRealityW = 	Uint4ToFloat(&buffer[HMI_DATA]);;
				printf("cameraRealityW:%f",DevParam.cameraRealityW);
				
				break;
			}
			case CMD_CAMERA_REALITY_L_OFFSET_CM:
			{
				DevParam.cameraRealityLOffset = 	Uint4ToFloat(&buffer[HMI_DATA]);;
				printf("cameraRealityLOffset:%f",DevParam.cameraRealityLOffset);
				break;
			}
			case CMD_CAMERA_REALITY_W_OFFSET_CM:
			{
				DevParam.cameraRealityWOffset = 	Uint4ToFloat(&buffer[HMI_DATA]);;
				printf("cameraRealityWOffset:%f",DevParam.cameraRealityWOffset);
				break;
			}
			case CMD_CONNECT:
			{
				uint8_t data = 1;
				upperComputer_SendCmdData(2,1,&data);
				upperComputer_AI_getSpeedGoverningState();
				upperComputer_AI_getTorqueGoverningState();
				break;
			}
			case CMD_RUN:
			{
				printf("CMD_RUN");
				//printf("sysState:%u",sysState);
				printf("buffer[HMI_DATA]:%u",buffer[HMI_DATA]);
				if(buffer[HMI_DATA] == 0x01)
				{
					if (sysState == SYSTEM_STANDBY) 
					{
						sysState = SYSTEM_RUN_AUTO;
					}
					
				}
				if(buffer[HMI_DATA] == 0x02)
				{
					// if (sysState == SYSTEM_RUN_AUTO) 
					// {
					// 	sysState = SYSTEM_STANDBY;
					// }
				}
				break;
			}
			case CMD_CLOCK_SYNCHRONOUS:
			{
				uint32_t time;
				//time = Uint4ToUint4Num(&buffer[5]);
				time = ((uint32_t)buffer[HMI_DATA]<<24)|((uint32_t)buffer[HMI_DATA+1]<<16)|((uint32_t)buffer[HMI_DATA+2]<<8)|((uint32_t)buffer[HMI_DATA+3]);
				RTC_SaveTimerForSeconds(time);
				break;
			}
			case CMD_MOTOR_SPEED_LOW:
			{
				if(buffer[HMI_DATA] == 0x01)
				{
					//DL_UART_transmitDataBlocking(UART_1_INST,9);
					//printf("\r\n1\r\n");
					//printf("\r\n低速\r\n");
					motor_speed(LOW);
				}
				break;
			}
			case CMD_MOTOR_SPEED_MEDIUM:
			{
				if(buffer[HMI_DATA] == 0x02)
				{
					//DL_UART_transmitDataBlocking(UART_1_INST,7);
					//printf("\r\n2\r\n");
					//printf("\r\n中速\r\n");
					motor_speed(MEDIUM);
				}
				break;
			}
			case CMD_MOTOR_SPEED_HIGH:
			{
				if(buffer[HMI_DATA] == 0x03)
				{
					//DL_UART_transmitDataBlocking(UART_1_INST,8);
					//printf("\r\n3\r\n");
					//printf("\r\n高速\r\n");
					motor_speed(HIGH);	
				}
				break;
			}
			case CMD_SCREDRIVER_SPEED_GOVVERNING:
			{
				if(buffer[HMI_DATA] == 0x01)
				{
					//printf("一等扭矩\r\n");
					//DL_UART_transmitDataBlocking(UART_RED_INST,1);
					MCTM0_PB9_setduty(0.8);
					scrediver_speed_state = SPEED_HIGH;
				}
				if(buffer[HMI_DATA] == 0x02)
				{
					//printf("二等扭矩\r\n");
					//DL_UART_transmitDataBlocking(UART_RED_INST,2);
					MCTM0_PB9_setduty(0.5);
					scrediver_speed_state = SPEED_MEDIUM;
				}
				if(buffer[HMI_DATA] == 0x03)
				{
					//printf("三等扭矩\r\n");
					//DL_UART_transmitDataBlocking(UART_RED_INST,3);
					MCTM0_PB9_setduty(0.3);
					scrediver_speed_state = SPEED_LOW;
				}
				break;
			}
		}
		runFlag = 0;
	}
	else
	{
		runFlag = 0;
		
	}
	
}






