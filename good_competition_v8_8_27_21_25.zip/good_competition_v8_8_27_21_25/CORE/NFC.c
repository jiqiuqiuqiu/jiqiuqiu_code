#include "NFC.h"
static uint8_t nfcDataBuffer[50];//设置一个NFC缓冲区

//初始化缓冲区的信息
RingBufferTypedef RingBuffer_nfcData = 
{
	.Head = nfcDataBuffer,//缓冲区的首元素
	.DataSize = sizeof(nfcDataBuffer)//缓冲区的大小
};



/**
  *@brief   NFC初始化
  *@param   无
  *@retval  无
  */
void nfc_Init(void)
{
	RingBuffer_Init(&RingBuffer_nfcData);
}

/**
  *@brief   数据处理
  *@param
  *@retval
  */
NFC_RESP nfc_dataDispose(void)
{
	uint8_t temp;
	uint8_t rx_Buf[20] = {0};
	
	if(RingBuffer_PeekOneNewData(&RingBuffer_nfcData,&temp)== BUF_OK)
	{
		if(temp == '\n')//接收到数据
		{
			RingBuffer_PopArrayData(&RingBuffer_nfcData,rx_Buf,RingBuffer_Count(&RingBuffer_nfcData));
			if(strstr((char *)rx_Buf,"FT+CAROK"))//解析数据 检测到是录入的卡
			{
				return NFC_CAROK;
			}
			else if(strstr((char *)rx_Buf,"FT+CARNO"))
			{
				return NFC_CARNO;
			}
			else if(strstr((char *)rx_Buf,"OK"))
			{
				return NFC_OK;
			}
		}
	}
	return NFC_NONE;
}

/**
  *@brief   NFC读取
  *@param   temp
  *@retval  无
  */
void nfc_uartReal(uint8_t temp)
{
		RingBuffer_PushOneData_Real(&RingBuffer_nfcData,temp);
}

/**
  *@brief   发送一个数据
  *@param   data
  *@retval  无
  */
void nfc_Send(uint8_t data)
{
	DL_UART_transmitDataBlocking(NFC_INST,data);
}


/**
  *@brief   发送一组数据
  *@param   data
  *         len
  *@retval
  */
void nfc_SendArray(uint8_t* data,uint16_t len)
{
	for(uint16_t i = 0;i < len;i++)
	{
		nfc_Send(data[i]); 
	}
}


/**
  *@brief   NFC注册
  *@param   无
  *@retval  无
  */
void nfc_register(void)
{
	const char str[] = "AT+CAR=REG";  // 注册命令
	nfc_SendArray((uint8_t *)str,strlen(str));  //发送命令
}


void nfc_test(void)
{
	nfc_register(); //发送注册命令
	while(nfc_dataDispose() != NFC_CAROK); //等待注册成功
}