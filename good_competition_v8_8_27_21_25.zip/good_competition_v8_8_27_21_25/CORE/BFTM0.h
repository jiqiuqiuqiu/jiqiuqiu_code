#ifndef __BFTM0_H
#define __BFTM0_H


#include "ti_msp_dl_config.h"

//extern vu32 bftm0_ct;

void BFTM0_Configuration(void);

#endif