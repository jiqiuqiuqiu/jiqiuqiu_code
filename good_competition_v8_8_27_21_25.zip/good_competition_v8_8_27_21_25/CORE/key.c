#include "key.h"
#include "ExtendTimer.h"
#include "UART_redirect.h"

//读取电平
uint32_t KEY1_GET(void)
{
	return DL_GPIO_readPins(KEY_PORT,KEY_key_1_PIN);
}

uint32_t KEY2_GET(void)
{
	return DL_GPIO_readPins(KEY_PORT,KEY_key_2_PIN);
}

uint32_t KEY3_GET(void)
{
	return DL_GPIO_readPins(KEY_PORT,KEY_key_3_PIN);
}

uint32_t KEY4_GET(void)
{
	return DL_GPIO_readPins(KEY_PORT,KEY_key_4_PIN);
}

uint32_t KEY5_GET(void)
{
	return DL_GPIO_readPins(KEY_PORT,KEY_key_5_PIN);
}


//获取按键
bool key_getSta(uint16_t keyNum)
{
	switch(keyNum)
	{
		case KEY_UPPER:
			return KEY1_GET();
		case KEY_RIGHT:
			return KEY2_GET();
		case KEY_DOWSN:
			return KEY3_GET();
		case KEY_MIDDLE:
			return KEY4_GET();
		case KEY_LEFT:
			return KEY5_GET();
	
	}
	return 0;
}

//结构体数组
KeyConfig keys[] = {
        {KEY_UPPER, KEY_STATE_RELEASED, KEY_EVENT_NONE, 0, 0},
	    {KEY_RIGHT, KEY_STATE_RELEASED, KEY_EVENT_NONE, 0, 0},
		{KEY_DOWSN, KEY_STATE_RELEASED, KEY_EVENT_NONE, 0, 0},
		{KEY_MIDDLE, KEY_STATE_RELEASED, KEY_EVENT_NONE, 0, 0},
		{KEY_LEFT, KEY_STATE_RELEASED, KEY_EVENT_NONE, 0, 0},
};

//按键扫描
void Key_Scan(void)
{
	uint32_t current_time = Etimer_GetTicks();
	
	for (uint8_t i = 0; i <= sizeof(keys)/sizeof(keys[0]); i++) 
	{
		bool current_pressed  = (key_getSta(keys[i].keyNum) == 0);//假设已经按下
		switch (keys[i].state)
		{
			case KEY_STATE_RELEASED://按键释放状态
					if(current_pressed)
					{
						keys[i].state = KEY_STATE_DEBOUNCE;//消抖状态
						keys[i].press_time = current_time;//开始计时
						keys[i].long_press_triggered = 0;
					}
				break;
			case KEY_STATE_DEBOUNCE://消抖状态
					if (current_time - keys[i].press_time >	DEBOUNCE_TIME) //大于消抖时间
					{
						if (current_pressed) 
						{
								keys[i].state = KEY_STATE_PRESSED;//已按下状态
								keys[i].is_pressed = true;
								
								keys[i].last_trigger_time = current_time;//上次触发时间
						}
						else	
						{
							 keys[i].state = KEY_STATE_RELEASED;//按键释放
						}
          }
				break;
			
			case KEY_STATE_PRESSED:	//按键按下状态
					if(!current_pressed)//没有按下
					{
						if (current_time - keys[i].press_time < SHORT_PRESS_TIME) // 按下时间小于短按阈值，触发短按
								keys[i].event = KEY_EVENT_SHORT_PRESS;
						else if(current_time - keys[i].press_time < LONG_PRESS_TIME)
								keys[i].event = KEY_EVENT_LONG_PRESS;
						
						keys[i].state = KEY_STATE_WAIT_RELEASE;
					}
					else
					{
								if (!keys[i].long_press_triggered && 
												(current_time - keys[i].last_trigger_time > LONG_PRESS_TIME)) 
								{	// 检查连续触发
										keys[i].long_press_triggered = 1;
										keys[i].last_trigger_time = current_time;
										keys[i].event = KEY_EVENT_CONTINUOUS;
										keys[i].last_trigger_time = current_time;
								}
								else if (keys[i].long_press_triggered && 
                            (current_time - keys[i].last_trigger_time > CONTINUOUS_INTERVAL)) 
								{
										keys[i].event = KEY_EVENT_CONTINUOUS;
										keys[i].last_trigger_time = current_time;
                 	}
				}
				break;
			case KEY_STATE_WAIT_RELEASE:
				if (!current_pressed) 
				{
						keys[i].state = KEY_STATE_RELEASED;
						keys[i].is_pressed = false;
		
        }
				break;
		}
	}
}

//获取按键事件（在主循环中调用）
KeyEvent Key_GetEvent(KeyNum key_id)
{
		KeyEvent event = KEY_EVENT_NONE;
		for(uint8_t i = 0;i<sizeof(keys)/sizeof(keys[0]);i++)
		{
			if(keys[i].keyNum == key_id)
			{
					event = keys[i].event;
					keys[i].event = KEY_EVENT_NONE; // 清除事件
			}
		}
    return event;
}

//清除所有事件
void  Key_CleanAllEvent(void)
{
		for(uint8_t i = 0;i<sizeof(keys)/sizeof(keys[0]);i++)
		{
				keys[i].event = KEY_EVENT_NONE;
		}
}

//按键事件测试
void key_test()
{
		for (int i = 0; i < sizeof(keys)/sizeof(keys[0]); i++) 
		{
				KeyEvent event = Key_GetEvent(i);
				
				switch (event) {
						case KEY_EVENT_SHORT_PRESS:
								printf("Key %d short pressed\n", i+1);
								// 短按处理代码
								break;
								
						case KEY_EVENT_LONG_PRESS:
								printf("Key %d long pressed\n", i+1);
								// 长按处理代码
								break;
								
						case KEY_EVENT_CONTINUOUS:
								printf("Key %d continuous trigger\n", i+1);
								// 连续触发处理代码
								break;
								
						default:
								break;
				}
		}
}