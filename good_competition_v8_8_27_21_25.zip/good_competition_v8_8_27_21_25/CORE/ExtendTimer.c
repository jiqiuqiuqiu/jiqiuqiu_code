#include "ExtendTimer.h"
#include "UART_redirect.h"

//可以无限扩展的软件定时器，可以定时运行任务，定时状态，以及计时

ETimer_TaskTypeDef * ETimerTask_handle = NULL;
volatile unsigned int _EtimerTicks;

//标志位状态置位器启动
void Etimer_FlagStart(ETimer_FlagTypeDef *ETimerFlag,uint32_t timer)
{	
	ETimerFlag-> repeat = timer;
	ETimerFlag -> cur_expired_time = _EtimerTicks;
	//ETimerFlag -> next = NULL;
	ETimerFlag -> sw = true;

}

//获取状态 并且清空标志位
bool Etimer_GetFlag(ETimer_FlagTypeDef *ETimerFlag)//获取状态 并且清空
{
 	ETimer_FlagTypeDef *ETimer = ETimerFlag;
	if(ETimerFlag -> sw  == false) return false;
	
	if(_EtimerTicks - (ETimer->cur_expired_time)>=ETimer->repeat)//判断时间
	{		
			ETimer->cur_expired_time = _EtimerTicks;
			return true;//时间到 标志位置 true
	}
	return false;
}

//标志位事件停止
void Etimer_FlagStop(ETimer_FlagTypeDef *ETimerFlag)
{
	ETimerFlag -> sw = false;
}

//任务初始化
void Etimer_TaskInit(ETimer_TaskTypeDef *ETimerTask,uint32_t timer,void (*fun)(void *arg),void *arg)
{
	ETimerTask ->repeat = timer;
	ETimerTask ->cur_expired_time = _EtimerTicks;
	ETimerTask ->fun = fun;
	ETimerTask ->arg = arg;
	ETimerTask->next = NULL;
	
}

//任务启动
int8_t Etimer_TaskStart(ETimer_TaskTypeDef *ETimerTask)
{	
	ETimer_TaskTypeDef *ETimerTaskH = ETimerTask_handle;
	ETimerTask->next = NULL;
	
	if(ETimerTask_handle == NULL) ETimerTask_handle = ETimerTask;//第一次
	else
	{
		if(ETimerTaskH == ETimerTask) return -1;// 判断是否重复
		 while(ETimerTaskH->next) {//寻找下一个的空指针
				if(ETimerTaskH->next == ETimerTask)
					return -1;
			 //寻找插入
			 ETimerTaskH = ETimerTaskH->next;
		 }
		 ETimerTaskH ->next = ETimerTask;
	}
	return 0;
}

//任务停止
int8_t Etimer_TaskStop(ETimer_TaskTypeDef *ETimerTask)
{	
	ETimer_TaskTypeDef *ETimerTaskHan = ETimerTask_handle; //获取第一个节点地址
	
	while(ETimerTaskHan)
	{
		if(ETimerTaskHan == ETimerTask)//如果是第一个 清除 
		{
			ETimerTask_handle = ETimerTask -> next;
			break; 
		}
		if(ETimerTaskHan->next == ETimerTask)//找到清除节点的上一个地址 
		{
			ETimerTaskHan->next = ETimerTask->next;//将清除节点的下一个地址赋值上一个节点 
			break; 
		}
		ETimerTaskHan = ETimerTaskHan->next;
	}
	return 0;
}

//任务运行
void Etimer_Taskloop(void)
{
	ETimer_TaskTypeDef *ETimerTaskHan = ETimerTask_handle;
	while (ETimerTaskHan)
	{
		if (_EtimerTicks - ETimerTaskHan->cur_expired_time >=  ETimerTaskHan->repeat)//判断时间
		{
			ETimerTaskHan->cur_expired_time = _EtimerTicks;
			ETimerTaskHan->fun(ETimerTaskHan->arg);//函数运行
		}
		ETimerTaskHan = ETimerTaskHan ->next;
	}
}

//计时开始
void Etimer_TimeStart(ETime_TimerTypeDef *ETimeTimer)
{
	ETimeTimer ->cw = true;
	ETimeTimer ->old_time = _EtimerTicks;
}


void Etimer_TimeInitStart(ETime_TimerTypeDef *ETimeTimer)
{
	ETimeTimer -> cw = true;
	ETimeTimer -> old_time = _EtimerTicks;
	ETimeTimer -> cur_time = 0;
	
}

void Etimer_TimeInit(ETime_TimerTypeDef *ETimeTimer)
{
	ETimeTimer -> cw = false;
	ETimeTimer -> old_time = _EtimerTicks;
	ETimeTimer -> cur_time = 0;
	
}

//获取计时时间
uint32_t Etimer_GetTime(ETime_TimerTypeDef *ETimeTimer)
{
	uint32_t _timer = _EtimerTicks;
	if(ETimeTimer -> cw == true)
	{
		ETimeTimer -> cur_time += (_timer - ETimeTimer ->old_time);
		ETimeTimer -> old_time = _timer;
	}
	return ETimeTimer->cur_time;
}

//计时停止
void Etimer_TimeStop(ETime_TimerTypeDef *ETimeTimer)
{
	ETimeTimer ->old_time = _EtimerTicks;
	ETimeTimer -> cw = false;
}

//计时器清0
void Etimer_ClearTime(ETime_TimerTypeDef *ETimeTimer)
{
	ETimeTimer ->cur_time = 0;
	ETimeTimer ->old_time = _EtimerTicks;
}

//标志位及任务的时基
void Etimer_Ticks(void)
{
	_EtimerTicks+=CFG_TIMER_1_TICK_N_MS;

}

uint32_t Etimer_GetTicks()
{
	return _EtimerTicks;
}