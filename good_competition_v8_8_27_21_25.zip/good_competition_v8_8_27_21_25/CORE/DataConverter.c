#include "DataConverter.h"


void floatToUint4(float num,uint8_t *buffer)
{
    //数据拆分
    unsigned char *p1 = (unsigned char*)&num;  //获取a的首地址
    unsigned char *p2 = (unsigned char*)&num + 1;//获取a的首地址的后一个字节地址
    unsigned char *p3 = (unsigned char*)&num + 2;//获取a的首地址的后两个字节地址
    unsigned char *p4 = (unsigned char*)&num + 3;//获取a的首地址的后三个字节地址
    buffer[0] = *p1;
    buffer[1] = *p2;
    buffer[2] = *p3;
    buffer[3] = *p4;
}


float Uint4ToFloat(uint8_t *buffer)
{
    float res;
    unsigned char *temp = (unsigned char*)&res;
    temp[0] = buffer[0];
    temp[1] = buffer[1];
    temp[2] = buffer[2];
    temp[3] = buffer[3];
    return  res;
}