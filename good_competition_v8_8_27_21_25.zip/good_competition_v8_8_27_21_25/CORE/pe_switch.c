#include "pe_switch.h"

volatile uint8_t PE_SWITCH_GET(void)
{
    uint32_t i  = 0;
    i = DL_GPIO_readPins(infrared_PORT, infrared_PA27_PIN);
    if(i)
    {
        return 0;
    }
    return 1;
}


















