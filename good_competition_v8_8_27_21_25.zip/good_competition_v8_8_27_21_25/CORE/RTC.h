#ifndef __RTC_H
#define __RTC_H

#include "ti_msp_dl_config.h"
#include <time.h>
#include "UART_redirect.h"

extern uint32_t rtc_ct;

void RTC_Configuration(void);
void RTC_SetTimeInSeconds(uint32_t seconds);
uint32_t RTC_GetTimeInSeconds(void);
time_t DatetimeToSeconds(int year, int month, int day, int hour, int minute, int second);
void SecondsToDatetime(time_t seconds, int *year, int *month, int *day,int *hour, int *minute, int *second);
void RTC_test(void);
void RTC_GetClock(int *year, int *month, int *day,int *hour, int *minute, int *second);
void RTC_SaveTimer(int year, int month, int day, int hour, int minute, int second);
void RTC_SaveTimerForSeconds(uint32_t seconds);

#endif