#include "clock.h"


bool IsLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

uint8_t getDaysinMonth(int year, int month) // 获取指定月份的天数
{
    // 月份有效性检查
    if (month < 1 || month > 12) {
        return 0;
    }

    // 各月份天数表
    const uint8_t days_per_month[] = {
        31, 28, 31, 30, 31, 30, 
        31, 31, 30, 31, 30, 31
    };
    
    // 如果是2月且闰年，返回29天
    if (month == 2 && IsLeapYear(year)) {
        return 29;
    }
    
    // 返回对应月份的天数
    return days_per_month[month - 1];
}


uint16_t get_days_in_year(int year) {
    return IsLeapYear(year) ? 366 : 365;
}