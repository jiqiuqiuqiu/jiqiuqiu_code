#include "Conveyor.h"


//传送带启动
void conveyor_start(void)
{

	DL_GPIO_setPins(Conveyor_PORT, Conveyor_con_PIN);
}

//传送带停止
void conveyor_stop(void)
{
    DL_GPIO_clearPins(Conveyor_PORT, Conveyor_con_PIN);
}


void conveyor_Init(void)
{
    conveyor_stop();
}

uint8_t conveyor_get_state(void)
{
    return DL_GPIO_readPins(Conveyor_PORT,Conveyor_con_PIN);
}

