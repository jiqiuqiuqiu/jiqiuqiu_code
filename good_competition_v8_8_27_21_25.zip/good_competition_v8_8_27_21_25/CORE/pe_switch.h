#ifndef PE_SWITCH_H  
#define PE_SWITCH_H

#include "ti_msp_dl_config.h"

volatile uint8_t PE_SWITCH_GET(void);

#endif



















