#ifndef _SYSTEM_H_
#define _SYSTEM_H_

#include "stdint.h"
#include "stdbool.h"

typedef enum{
	SYSTEM_LOCK = 0,
	SYSTEM_REST,
	SYSTEM_STANDBY,//待机 暂停
	SYSTEM_RUN_AUTO,
	SYSTEM_RUN_MANUAL_CONTRIL	//手动控制
}systemStateEnum;


extern systemStateEnum sysState;


typedef struct
{
	bool conveyr;

}SystemStandbyStateTypedef;

extern SystemStandbyStateTypedef SystemStandbyState;//传送带暂停待机传送带的状态




#endif