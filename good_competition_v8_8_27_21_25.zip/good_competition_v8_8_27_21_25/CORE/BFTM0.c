#include "BFTM0.h"
#include "ExtendTimer.h"

//1ms进入中断
void BFTM0_Configuration(void)
{
    DL_TimerG_enableInterrupt(BFTM0_INST, DL_TIMER_IIDX_ZERO);
    NVIC_EnableIRQ(BFTM0_INST_INT_IRQN);
    DL_TimerG_startCounter(BFTM0_INST);
}

void BFTM0_INST_IRQHandler(void)
{
    if(DL_TimerG_getEnabledInterruptStatus(BFTM0_INST,DL_TIMER_IIDX_ZERO))//获取定时器0的中断
    {
        DL_TimerG_clearInterruptStatus(BFTM0_INST,DL_TIMER_IIDX_ZERO);
        Etimer_Ticks();
    }
}