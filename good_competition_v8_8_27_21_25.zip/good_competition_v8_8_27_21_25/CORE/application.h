#ifndef _APPLICATION_H_
#define _APPLICATION_H_

#include <stdint.h>
#include <stdbool.h>
#include "ExtendTimer.h"

void run(void);



#define HMI_FRAME_HEADER_H 0
#define HMI_FRAME_HEADER_L 1
#define HMI_CMD 2
#define HMI_DATA_LEN 3
#define HMI_DATA 4

/************/
#define  CMD_RUN	0x0
#define  CMD_PIXEL_L 0x11 
#define  CMD_PIXEL_W 0x12
#define  CMD_CAMERA_REALITY_L_CM 0x13
#define  CMD_CAMERA_REALITY_W_CM 0x14
#define  CMD_CAMERA_REALITY_L_OFFSET_CM 0x15
#define  CMD_CAMERA_REALITY_W_OFFSET_CM 0x16
#define  CMD_CONNECT 	0x02
#define  CMD_CLOCK_SYNCHRONOUS 0x17
#define	 CMD_MOTOR_SPEED_LOW 0x18
#define	 CMD_MOTOR_SPEED_MEDIUM 0x19
#define	 CMD_MOTOR_SPEED_HIGH 0x20
#define	 CMD_SCREDRIVER_SPEED_GOVVERNING 0x21

/*********/
#define HMI_DATA_CRC 		1
#define AI_MENU_TEST 	0
#define ADJUSTMENT_PARAMETETR 1
#define CONVEYOR  1   //流水线
#define PE_SWITCH 1

#define PICKSCREW 1		//抓螺丝
#define AI_CAMERA_TEST 0


#define CAMERA_PIXEL_L (float)1280 
#define CAMERA_PIXEL_W (float)720


#define CAMERA_REALITY_L_CM 	(float)25.92
#define CAMERA_REALITY_W_CM  	(float)14.75

#define CAMERA_REALITY_L_OFFSET_CM 3.20 //8+(3)
#define CAMERA_REALITY_W_OFFSET_CM 4.09 //5+(3)


#define COMPENSATION 1 //补偿


#if (COMPENSATION == 1)
/*********补偿参数********/
//X为正：向右调；y为正：向上调；
#define X_1_CM (-0.24)	//第一象限
#define Y_1_CM (0.225)
#define X_2_CM (-0.115)	//第二象限
#define Y_2_CM (0.08)
#define X_3_CM (-0.08)	//第三象限
#define Y_3_CM (0.345)
#define X_4_CM (-0.175)	//第四象限
#define Y_4_CM (0.243)			 
#else
#define X_1_CM (0)	//第一象限
#define Y_1_CM (0)
#define X_2_CM (0)	//第二象限
#define Y_2_CM (0)
#define X_3_CM (0)	//第三象限
#define Y_3_CM (0)
#define X_4_CM (0)	//第四象限
#define Y_4_CM (0)

#endif

typedef struct{
	uint16_t pixel_L;//CAMERA_PIXEL_L
	uint16_t pixel_W;//CAMERA_PIXEL_W
	float cameraRealityL;//CAMERA_REALITY_L_CM
	float cameraRealityW;//CAMERA_REALITY_W_CM
	float cameraRealityLOffset;//CAMERA_REALITY_L_OFFSET_CM
	float cameraRealityWOffset;//CAMERA_REALITY_W_OFFSET_CM
}DevParamTypedef;


typedef struct{
	uint8_t runFlag;
	bool conveyor_flag;//传送带
	
}ScrewMachineMovemenTaskFlagDef;



typedef enum{
	TASK_INIT = 0,
	TASK_RUN
}TaskState;



extern uint32_t AutoModeCount;//自动模式计数
extern uint32_t regularTime;//定时
extern bool regularTimeSwitch;//定时开关
extern uint32_t regularTimerRtcCount;//定时时间计数

// void AI_Cam_test(void);
void computerDataProcessing(void);
uint8_t pickScrewTask(TaskState taskState);
// void ScrewMachineMovement(TaskState state);
// uint8_t AiTightenScrewTask(TaskState state);
// uint8_t pickScrewTask(TaskState taskState);
void ScrewMachineMovement(void);
void init(void);
uint8_t AiTightenScrewTask(TaskState taskState);

#endif







