#include "UART1.h"
#include "UART_redirect.h"

uint8_t  RX1_Buffer[USART1_BUF_SIZE]; //自定义接收缓冲区
QUEUE_HandleTypeDef QUEUE_Rx1Data; //结构体变量，在queue.h文件中

RingBufferTypedef RingBuffer_RX1; //结构体变量，在RingBuffer.h文件中

void USART1_Configuration(void)
{
    //设置FIFO阈值
    DL_UART_setTXFIFOThreshold(UART_1_INST,DL_UART_TX_FIFO_LEVEL_ONE_ENTRY);
    DL_UART_setRXFIFOThreshold(UART_1_INST,DL_UART_RX_FIFO_LEVEL_ONE_ENTRY);
//使能中断
    NVIC_EnableIRQ(UART_1_INST_INT_IRQN);
    //使能接收中断和超时中断
    DL_UART_enableInterrupt(UART_1_INST, DL_UART_IIDX_RX | DL_UART_IIDX_RX_TIMEOUT_ERROR);
    //DL_UART_transmitData(UART_1_INST, 'A');
    RingBuffer_RX1.Head = &RX1_Buffer[0];
    RingBuffer_RX1.DataSize = USART1_BUF_SIZE;
    RingBuffer_Init(&RingBuffer_RX1);
}

void UART_1_INST_IRQHandler(void)
{
    if(DL_UART_getPendingInterrupt(UART_1_INST)==DL_UART_IIDX_RX)//接收中断触发
    {

        // uint8_t temp = DL_UART_receiveDataBlocking(UART_1_INST);
        // DL_UART_transmitDataBlocking(UART_1_INST, temp);
        //先判断FIFO是否已经达到阈值，达到则读取数据
        DL_UART_clearInterruptStatus(UART_1_INST, DL_UART_IIDX_RX);
        while(DL_UART_isRXFIFOFull(UART_1_INST))
        {
            uint8_t temp = DL_UART_receiveDataBlocking(UART_1_INST);
         
            RingBuffer_PushOneData_Real(&RingBuffer_RX1,temp);
        }

    }
    //在规定的时间里没有接收到新的数据，那么就从FIFO中读取数据
    else if(DL_UART_getPendingInterrupt(UART_1_INST)==DL_UART_IIDX_RX_TIMEOUT_ERROR)
    {
        DL_UART_clearInterruptStatus(UART_1_INST,DL_UART_IIDX_RX_TIMEOUT_ERROR);
        while(DL_UART_isRXFIFOFull(UART_1_INST))
        {
            uint8_t temp = DL_UART_receiveDataBlocking(UART_1_INST);
            RingBuffer_PushOneData_Real(&RingBuffer_RX1,temp);
        }
    }
}