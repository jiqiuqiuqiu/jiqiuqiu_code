#ifndef _UPPERCOMPUTER_H_
#define _UPPERCOMPUTER_H_

//上位机通信
#include "UART1.h"

#define COMPUTER_PORT  HT_USART1

void upperComputer_Send(uint8_t data);
void upperComputer_SendCmdData(uint8_t cmd,uint8_t dataNum,uint8_t *data);
void upperComputer_SendArray(uint8_t *data,uint16_t len);

void upperComputer_AI_startRecog(void);
void upperComputer_AI_stopRecog(void);

void upperComputer_SendCount(uint32_t data);
void upperComputer_AI_getSpeedGoverningState(void);
void upperComputer_AI_getTorqueGoverningState(void);

#endif