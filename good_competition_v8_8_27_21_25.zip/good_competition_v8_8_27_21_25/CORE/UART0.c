#include "UART0.h"
#include "NFC.h"
//串口超时时间为468.75ns



//串口初始化
void UART0_Configuration(void)
{   
    //设置FIFO阈值，4字节
    DL_UART_setTXFIFOThreshold(NFC_INST , DL_UART_TX_FIFO_LEVEL_ONE_ENTRY);
    DL_UART_setRXFIFOThreshold(NFC_INST , DL_UART_RX_FIFO_LEVEL_ONE_ENTRY);
    //使能接收中断和超时中断
    NVIC_EnableIRQ(NFC_INST_INT_IRQN);     //使能串口0中断
    DL_UART_enableInterrupt(NFC_INST, DL_UART_IIDX_RX | DL_UART_IIDX_RX_TIMEOUT_ERROR);
}

void NFC_INST_IRQHandler(void)
{
    if(DL_UART_getPendingInterrupt(NFC_INST)== DL_UART_IIDX_RX)
    {  
        DL_UART_clearInterruptStatus(NFC_INST, DL_UART_IIDX_RX);
        //如果FIFO有数据
        while(!DL_UART_isRXFIFOEmpty(NFC_INST))
        {
            uint8_t temp = DL_UART_receiveDataBlocking(NFC_INST);
            nfc_uartReal(temp);   
        }
    }
    //超时判断,仍然读取 FIFO 剩余数据，并通过NFC协议上传
    else if(DL_UART_getPendingInterrupt(NFC_INST)== DL_UART_IIDX_RX_TIMEOUT_ERROR)
    {
        DL_UART_clearInterruptStatus(NFC_INST, DL_UART_IIDX_RX_TIMEOUT_ERROR);
        while(!DL_UART_isRXFIFOEmpty(NFC_INST))
        {
            uint8_t temp = DL_UART_receiveDataBlocking(NFC_INST);
            nfc_uartReal(temp);
        }
    } 
}
