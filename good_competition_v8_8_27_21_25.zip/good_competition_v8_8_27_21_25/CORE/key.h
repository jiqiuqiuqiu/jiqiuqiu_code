#ifndef _KEY_H_
#define _KEY_H_

#include <stdint.h>
#include <stdio.h>
#include "ti_msp_dl_config.h"
#include "UART_redirect.h"

typedef enum {
	KEY_UPPER = 0,//上键
	KEY_RIGHT,//右
	KEY_DOWSN ,//下
	KEY_MIDDLE ,//中
	KEY_LEFT //左
}KeyNum;

typedef enum {
    KEY_STATE_RELEASED = 0,     // 按键释放
    KEY_STATE_DEBOUNCE,     // 消抖状态
    KEY_STATE_PRESSED,      // 已按下
    KEY_STATE_WAIT_RELEASE  // 等待释放
} KeyState;

typedef enum {
    KEY_EVENT_NONE = 0,        // 无事件
    KEY_EVENT_SHORT_PRESS, // 短按事件
    KEY_EVENT_LONG_PRESS,   // 长按事件
		KEY_EVENT_CONTINUOUS     // 连续触发事件
} KeyEvent;

typedef struct {
    uint16_t keyNum; // 按键号
    KeyState state;                 // 当前状态
    KeyEvent event;                 // 触发事件
    uint32_t press_time;            // 按下时间戳
	uint32_t last_trigger_time;     // 上次触发时间
    bool  is_pressed;            // 当前是否按下
	uint8_t  long_press_triggered;  // 长按连续触发标志
} KeyConfig;

#define DEBOUNCE_TIME     20    // 消抖时间，0.16ms
#define SHORT_PRESS_TIME  300   // 短按时间阈值 ，2.7ms
#define LONG_PRESS_TIME   1000  // 长按时间阈值 ， 8ms
#define CONTINUOUS_INTERVAL   200    // 连续触发间隔 ，1.6ms

//读取电平函数
uint32_t KEY1_GET(void);
uint32_t KEY2_GET(void);
uint32_t KEY3_GET(void);
uint32_t KEY4_GET(void);
uint32_t KEY5_GET(void);

// void key_GPIOConfig(void);
void Key_Scan(void);
KeyEvent Key_GetEvent(KeyNum key_id);
void key_test(void);
void  Key_CleanAllEvent(void);

#endif