#ifndef _DATACONVERTER_H_
#define _DATACONVERTER_H_

#include "stdint.h"

float Uint4ToFloat(uint8_t *buffer);

void floatToUint4(float num,uint8_t *buffer);
uint32_t Uint4ToUint4Num(uint8_t *buffer);
#endif