#ifndef CONVEYOR_H_
#define CONVEYOR_H_
//传送带
#include "ti_msp_dl_config.h"

void conveyor_start(void);
void conveyor_stop(void);

void  conveyor_Init(void);
uint8_t conveyor_get_state(void);

#endif



