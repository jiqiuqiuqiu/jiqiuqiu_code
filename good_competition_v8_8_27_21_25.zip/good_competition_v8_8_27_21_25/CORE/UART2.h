#ifndef __UART2_H
#define __UART2_H

#include "ti_msp_dl_config.h"

#define UART2_BUF_SIZE 256
#define UART2_FIFO_LEN 1


typedef struct
{
  uint8_t buffer[UART2_BUF_SIZE];
  uint16_t write_pt;
  uint16_t read_pt;
  uint16_t cnt;
}_UART2_STRUCT;

void UART2_Configuration(void);
void UART2_init_buffer (void);
void UART2_analyze_data(void);
void UART2_tx_data(uint8_t *pt, uint8_t len);
void UART2_test(void);

#endif