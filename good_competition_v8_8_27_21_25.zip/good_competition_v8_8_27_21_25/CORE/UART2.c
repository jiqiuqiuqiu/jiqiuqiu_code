#include "UART2.h"
#include "NFC.h"

__attribute__((aligned(4))) _UART2_STRUCT rxd_comm2;

__attribute__((aligned(4))) _UART2_STRUCT txd_comm2;

uint8_t temp1 = 0;

//串口初始化
void UART2_Configuration(void)
{
    NVIC_EnableIRQ(UART_2_INST_INT_IRQN);
    DL_UART_enableInterrupt(UART_2_INST, DL_UART_IIDX_RX);
    UART2_init_buffer();
}

//数据缓冲区
void UART2_init_buffer (void)
{
    // 初始化接收缓冲区指针和计数器
  rxd_comm2.read_pt = 0;						//读指针（从缓冲区读取数据的位置）
  rxd_comm2.write_pt = 0;						//写指针（向缓冲区写入数据的位置）
  rxd_comm2.cnt = 0;								//缓冲区中当前存储的数据数量
	//初始化发送缓冲区指针和计数器
  txd_comm2.read_pt = 0;
  txd_comm2.write_pt = 0;
  txd_comm2.cnt = 0;
}

void UART_2_INST_IRQHandler(void)
{
    switch (DL_UART_getPendingInterrupt(UART_2_INST)) 
    {
        case DL_UART_IIDX_EOT_DONE:
            if (!txd_comm2.cnt)
            {
                DL_UART_clearInterruptStatus(UART_2_INST, DL_UART_IIDX_EOT_DONE);
            }
            else 
            {
              DL_UART_clearInterruptStatus(UART_2_INST, DL_UART_IIDX_EOT_DONE);
              uint16_t i;
              for (i = 0; i < UART2_FIFO_LEN; i++)   //have FIFO?
              {
                  DL_UART_transmitDataBlocking(UART_2_INST, txd_comm2.buffer[txd_comm2.read_pt]);
                  txd_comm2.read_pt = (txd_comm2.read_pt + 1) % UART2_BUF_SIZE;
                  txd_comm2.cnt--;
              if (!txd_comm2.cnt)
                  break;
              }
            }
            break;
        case DL_UART_IIDX_RX:
          DL_UART_clearInterruptStatus(UART_2_INST,DL_UART_IIDX_RX);
          temp1 = DL_UART_receiveDataBlocking(UART_2_INST);
		      nfc_uartReal(temp1);
          break;
        default:
            break;
    
    }
}

void UART2_analyze_data(void)
{
    uint8_t tmp;
    if(!rxd_comm2.cnt)
      return;

    //...to be add
    tmp = rxd_comm2.buffer[rxd_comm2.read_pt];
    if( (tmp != 0xAA) )            //for example
    {
      NVIC_DisableIRQ(UART_2_INST_INT_IRQN);
      rxd_comm2.cnt--;  //throw invalid data
      NVIC_EnableIRQ(UART_2_INST_INT_IRQN);
      rxd_comm2.read_pt = (rxd_comm2.read_pt + 1) % UART2_BUF_SIZE;
      return;
    }
    else if(rxd_comm2.cnt >= 8)    //for example
    {
      //add your code here

    }
}
void UART2_tx_data(uint8_t *pt, uint8_t len)
{
  while(len--)
  {
    txd_comm2.buffer[txd_comm2.write_pt] = *pt++;
    txd_comm2.write_pt = (txd_comm2.write_pt + 1) % UART2_BUF_SIZE;
    NVIC_DisableIRQ(UART_2_INST_INT_IRQN);
    txd_comm2.cnt++;
    NVIC_EnableIRQ(UART_2_INST_INT_IRQN);
  }

  if(txd_comm2.cnt)
  {
    DL_UART_enableInterrupt(UART_2_INST,DL_UART_IIDX_EOT_DONE);
  }

}

void UART2_test(void)
{
  uint8_t i,test_array[8];
  for(i=0; i<8; i++)
  {
    test_array[i] = i;
  }
  UART2_tx_data(test_array, 8);
}












