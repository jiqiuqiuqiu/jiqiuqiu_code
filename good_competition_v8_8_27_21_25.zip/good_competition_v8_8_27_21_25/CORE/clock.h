#ifndef _CLOCK_H_
#define _CLOCK_H_

#include "stdint.h"
#include <stdbool.h>

bool IsLeapYear(int year);
uint8_t getDaysinMonth(int year, int month);
uint16_t get_days_in_year(int year);

#endif