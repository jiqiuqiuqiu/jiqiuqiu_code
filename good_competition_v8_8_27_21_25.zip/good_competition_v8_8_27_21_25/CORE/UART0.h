#ifndef __UART0_H__
#define __UART0_H__

#include "ti_msp_dl_config.h"

#define USART0_BUF_SIZE 256
#define USART0_FIFO_LEN 1

typedef struct
{
  uint8_t buffer[USART0_BUF_SIZE];
  uint16_t write_pt;
  uint16_t read_pt;
  uint16_t cnt;
}_USART0_STRUCT;

void UART0_Configuration(void);

#endif













