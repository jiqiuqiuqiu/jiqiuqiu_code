#ifndef __NFC_H_
#define __NFC_H_

#include "ti_msp_dl_config.h"
#include "RingBuffer.h"
#include <string.h>


typedef enum{
	NFC_CAROK = 0,
	NFC_CARNO,
	NFC_OK,
	NFC_NONE,

}NFC_RESP;

void nfc_Init(void);
void nfc_uartReal(uint8_t temp);
NFC_RESP nfc_dataDispose(void);

void nfc_test(void);


#endif