#include "RTC.h"
#include "clock.h"

uint32_t rtc_ct;
uint32_t backupsClock = 0;
uint32_t setClock = 0;

//-----------------------------------------------------------------------------
void RTC_Configuration(void)
{
    NVIC_EnableIRQ(RTC_INT_IRQn);
    DL_RTC_Common_enableClockControl(RTC);
    // 设置初始时间并备份当前RTC时间
    setClock = DatetimeToSeconds(2025, 5, 19, 6, 15, 30);
    backupsClock = RTC_GetTimeInSeconds();
}

void RTC_IRQHandler(void)
{
    {
        rtc_ct = 1; // time update interrupt
        DL_RTC_clearInterruptStatus(RTC, DL_RTC_INTERRUPT_INTERVAL_ALARM); // clear interrupt flags
    }
}

/**
 * @brief 设置RTC时间（以秒为单位）
 * @param seconds 要设置的秒数
 */


//设置RTC时间（秒为单位）
void RTC_SetTimeInSeconds(uint32_t seconds)
{
    //禁止写保护
    RTC->RTCLOCK = 0xA500;
    
    DL_RTC_setCalendarSecondsBinary(RTC, seconds % 60);
    DL_RTC_setCalendarMinutesBinary(RTC, (seconds / 60) % 60);
    DL_RTC_setCalendarHoursBinary(RTC, (seconds / 3600) % 24);
    //开启写保护
    RTC->RTCLOCK = 0xA501;

}


//从RTC寄存器读取时、分、秒，合并为一个从0开始的总秒数（如 86399 表示23:59:59）
uint32_t RTC_GetTimeInSeconds(void)
{
    uint32_t seconds = DL_RTC_getCalendarSecondsBinary(RTC);
    seconds += DL_RTC_getCalendarMinutesBinary(RTC) * 60;
    seconds += DL_RTC_getCalendarHoursBinary(RTC) * 3600;
    return seconds;
}

/**
 * @brief 将年月日时分秒转换为秒
 * @param year 年
 * @param month 月
 * @param day 日
 * @param hour 时
 * @param minute 分
 * @param second 秒
 * @return 转换后的秒数
 */
time_t DatetimeToSeconds(int year, int month, int day, int hour, int minute, int second) {
    struct tm time_struct = {0};
    
    time_struct.tm_year = year - 1900;
    time_struct.tm_mon = month - 1;
    time_struct.tm_mday = day;
    time_struct.tm_hour = hour;
    time_struct.tm_min = minute;
    time_struct.tm_sec = second;
    time_struct.tm_isdst = -1;
    
    return mktime(&time_struct);
}

/**
 * @brief 将秒转换为年月日时分秒
 * @param seconds 秒数
 * @param year 年指针
 * @param month 月指针
 * @param day 日指针
 * @param hour 时指针
 * @param minute 分指针
 * @param second 秒指针
 */
void SecondsToDatetime(time_t seconds, int *year, int *month, int *day, 
                      int *hour, int *minute, int *second) {
    struct tm *time_struct;
    
    time_struct = localtime(&seconds);
    
    *year = time_struct->tm_year + 1900;
    *month = time_struct->tm_mon + 1;
    *day = time_struct->tm_mday;
    *hour = time_struct->tm_hour;
    *minute = time_struct->tm_min;
    *second = time_struct->tm_sec;
}

/**
 * @brief 获取当前RTC时间
 * @param year 年指针
 * @param month 月指针
 * @param day 日指针
 * @param hour 时指针
 * @param minute 分指针
 * @param second 秒指针
 */
void RTC_GetClock(int *year, int *month, int *day, 
                 int *hour, int *minute, int *second)
{
    time_t time = RTC_GetTimeInSeconds();
    time_t time1 = setClock + (time - backupsClock);
    SecondsToDatetime(time1, year, month, day, hour, minute, second);
}

/**
 * @brief 测试函数，打印当前RTC时间
 */
void RTC_test()
{
    time_t time = RTC_GetTimeInSeconds();
    time_t time1 = setClock + (time - backupsClock);
    
    int year, month, day, hour, minute, second;
    SecondsToDatetime(time1, &year, &month, &day, &hour, &minute, &second);
    printf("%d-%d-%d %d:%d:%d\r\n", year, month, day, hour, minute, second);
}

/**
 * @brief 保存指定的日期时间
 * @param year 年
 * @param month 月
 * @param day 日
 * @param hour 时
 * @param minute 分
 * @param second 秒
 */
void RTC_SaveTimer(int year, int month, int day, int hour, int minute, int second)
{
    setClock = DatetimeToSeconds(year, month, day, hour, minute, second);
    backupsClock = RTC_GetTimeInSeconds();
}

/**
 * @brief 保存指定的秒数时间
 * @param seconds 秒数
 */
void RTC_SaveTimerForSeconds(uint32_t seconds)
{
    setClock = seconds;
    backupsClock = RTC_GetTimeInSeconds();
}