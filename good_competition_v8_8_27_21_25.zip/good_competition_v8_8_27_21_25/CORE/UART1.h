#ifndef __USART1_H
#define __USART1_H

#include "ti_msp_dl_config.h"
#include "RingBuffer.h"
#include "queue.h"

#define USART1_BUF_SIZE 256*2
#define USART1_FIFO_LEN 1

typedef struct
{
  uint8_t buffer[USART1_BUF_SIZE];
  uint16_t write_pt;
  uint16_t read_pt;
  uint16_t cnt;
}_USART1_STRUCT;

extern QUEUE_HandleTypeDef QUEUE_Rx1Data;
extern RingBufferTypedef RingBuffer_RX1;

//串口初始化函数
void USART1_Configuration(void);
void USART1_analyze_data(void);
void USART1_test(void);


#endif