#include "upperComputer.h"
#include "CRC.h"

//发送一个数据
void upperComputer_Send(uint8_t data)
{
	DL_UART_transmitDataBlocking(UART_1_INST,data);//发送给上位机
}

//发送一组数据数组
void upperComputer_SendArray(uint8_t *data,uint16_t len)
{
	for(int i = 0;i < len;i++)
	{
		upperComputer_Send(data[i]); 
	}
}

//发送一组数据指令
void upperComputer_SendCmdData(uint8_t cmd,uint8_t dataNum,uint8_t *data)
{
	uint8_t buffer[40] = {cmd,dataNum};//0xA9,0x9A,
	uint8_t i = 0;
	for( i = 0;i<dataNum;i++)
	{
		buffer[i+2] = data[i];
	}
	buffer[i+2] = crc8(buffer,dataNum+2,crc_8);
	upperComputer_Send(0xA9);
	upperComputer_Send(0x9A);
	upperComputer_SendArray(buffer,dataNum+3);
	upperComputer_Send(0xFF);
}

//开始识别
void upperComputer_AI_startRecog(void)
{
	uint8_t buffer[] = {1};
	upperComputer_SendCmdData(1,1,buffer);
}

//计数
void upperComputer_SendCount(uint32_t data)
{
	
	uint8_t buffer[] = {(uint8_t)(data>>24),(uint8_t)data>>16,(uint8_t)(data>>8),(uint8_t)data};
	upperComputer_SendCmdData(0x04,4,(uint8_t *)&buffer[0]);

	uint32_t ti = ((uint32_t)buffer[0]<<24)|((uint32_t)buffer[1]<<16)|((uint32_t)buffer[2]<<8)|((uint32_t)buffer[3]);	
}

//发送扭力状态
void upperComputer_AI_getTorqueGoverningState(void)
{
	uint8_t buffer[] = {2};
	upperComputer_SendCmdData(4,1,buffer);
}

//发送速度状态
void upperComputer_AI_getSpeedGoverningState(void)
{
	uint8_t buffer[] = {2};
	upperComputer_SendCmdData(5,1,buffer);
}









