#ifndef _CRC_H_
#define _CRC_H_

#include <stdint.h>
#include <stdbool.h>

typedef struct
{
	uint8_t poly;//多项式
	uint8_t InitValue;//初始值
	uint8_t xor;//结果异或值
	bool InputReverse;
	bool OutputReverse;
}CRC_8;

extern const CRC_8 crc_8;
extern const CRC_8 crc_8_ITU;
extern const CRC_8 crc_8_ROHC;
extern const CRC_8 crc_8_MAXIM;

uint8_t crc8(uint8_t *addr, int num,CRC_8 type) ;

#endif