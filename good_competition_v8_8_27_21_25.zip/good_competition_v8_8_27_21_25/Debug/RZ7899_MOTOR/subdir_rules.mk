################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
RZ7899_MOTOR/%.o: ../RZ7899_MOTOR/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"D:/CCSTUDIO/ccs/tools/compiler/ti-cgt-armllvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"D:/TI_project/good_competition_v7/motor" -I"D:/TI_project/good_competition_v7/CORE" -I"D:/TI_project/good_competition_v7/RingBuffer" -I"D:/TI_project/good_competition_v7/RZ7899_MOTOR" -I"D:/TI_project/good_competition_v7/UART_redirect" -I"D:/TI_project/good_competition_v7" -I"D:/TI_project/good_competition_v7/Debug" -I"D:/CCSTUDIO/mspm0_sdk_2_04_00_06/source/third_party/CMSIS/Core/Include" -I"D:/CCSTUDIO/mspm0_sdk_2_04_00_06/source" -gdwarf-3 -MMD -MP -MF"RZ7899_MOTOR/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


