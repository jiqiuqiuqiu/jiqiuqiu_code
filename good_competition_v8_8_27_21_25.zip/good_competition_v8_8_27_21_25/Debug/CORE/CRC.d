# FIXED

CORE/CRC.o: ../CORE/CRC.c ../CORE/CRC.h
../CORE/CRC.h:
