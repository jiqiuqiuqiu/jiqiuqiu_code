# FIXED

CORE/DataConverter.o: ../CORE/DataConverter.c ../CORE/DataConverter.h
../CORE/DataConverter.h:
