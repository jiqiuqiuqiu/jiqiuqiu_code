# FIXED

CORE/clock.o: ../CORE/clock.c ../CORE/clock.h
../CORE/clock.h:
