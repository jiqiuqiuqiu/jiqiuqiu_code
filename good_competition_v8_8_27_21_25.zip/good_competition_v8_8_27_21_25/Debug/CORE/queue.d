# FIXED

CORE/queue.o: ../CORE/queue.c ../CORE/queue.h
../CORE/queue.h:
