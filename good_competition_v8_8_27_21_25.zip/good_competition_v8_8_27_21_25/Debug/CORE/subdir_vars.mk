################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../CORE/BFTM0.c \
../CORE/CRC.c \
../CORE/Conveyor.c \
../CORE/DataConverter.c \
../CORE/ExtendTimer.c \
../CORE/NFC.c \
../CORE/RTC.c \
../CORE/UART0.c \
../CORE/UART1.c \
../CORE/UART2.c \
../CORE/application.c \
../CORE/clock.c \
../CORE/key.c \
../CORE/pe_switch.c \
../CORE/queue.c \
../CORE/upperComputer.c 

C_DEPS += \
./CORE/BFTM0.d \
./CORE/CRC.d \
./CORE/Conveyor.d \
./CORE/DataConverter.d \
./CORE/ExtendTimer.d \
./CORE/NFC.d \
./CORE/RTC.d \
./CORE/UART0.d \
./CORE/UART1.d \
./CORE/UART2.d \
./CORE/application.d \
./CORE/clock.d \
./CORE/key.d \
./CORE/pe_switch.d \
./CORE/queue.d \
./CORE/upperComputer.d 

OBJS += \
./CORE/BFTM0.o \
./CORE/CRC.o \
./CORE/Conveyor.o \
./CORE/DataConverter.o \
./CORE/ExtendTimer.o \
./CORE/NFC.o \
./CORE/RTC.o \
./CORE/UART0.o \
./CORE/UART1.o \
./CORE/UART2.o \
./CORE/application.o \
./CORE/clock.o \
./CORE/key.o \
./CORE/pe_switch.o \
./CORE/queue.o \
./CORE/upperComputer.o 

OBJS__QUOTED += \
"CORE\BFTM0.o" \
"CORE\CRC.o" \
"CORE\Conveyor.o" \
"CORE\DataConverter.o" \
"CORE\ExtendTimer.o" \
"CORE\NFC.o" \
"CORE\RTC.o" \
"CORE\UART0.o" \
"CORE\UART1.o" \
"CORE\UART2.o" \
"CORE\application.o" \
"CORE\clock.o" \
"CORE\key.o" \
"CORE\pe_switch.o" \
"CORE\queue.o" \
"CORE\upperComputer.o" 

C_DEPS__QUOTED += \
"CORE\BFTM0.d" \
"CORE\CRC.d" \
"CORE\Conveyor.d" \
"CORE\DataConverter.d" \
"CORE\ExtendTimer.d" \
"CORE\NFC.d" \
"CORE\RTC.d" \
"CORE\UART0.d" \
"CORE\UART1.d" \
"CORE\UART2.d" \
"CORE\application.d" \
"CORE\clock.d" \
"CORE\key.d" \
"CORE\pe_switch.d" \
"CORE\queue.d" \
"CORE\upperComputer.d" 

C_SRCS__QUOTED += \
"../CORE/BFTM0.c" \
"../CORE/CRC.c" \
"../CORE/Conveyor.c" \
"../CORE/DataConverter.c" \
"../CORE/ExtendTimer.c" \
"../CORE/NFC.c" \
"../CORE/RTC.c" \
"../CORE/UART0.c" \
"../CORE/UART1.c" \
"../CORE/UART2.c" \
"../CORE/application.c" \
"../CORE/clock.c" \
"../CORE/key.c" \
"../CORE/pe_switch.c" \
"../CORE/queue.c" \
"../CORE/upperComputer.c" 


