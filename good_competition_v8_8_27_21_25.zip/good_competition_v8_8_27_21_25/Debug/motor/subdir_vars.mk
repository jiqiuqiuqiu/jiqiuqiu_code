################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../motor/SN04.c \
../motor/motor.c 

C_DEPS += \
./motor/SN04.d \
./motor/motor.d 

OBJS += \
./motor/SN04.o \
./motor/motor.o 

OBJS__QUOTED += \
"motor\SN04.o" \
"motor\motor.o" 

C_DEPS__QUOTED += \
"motor\SN04.d" \
"motor\motor.d" 

C_SRCS__QUOTED += \
"../motor/SN04.c" \
"../motor/motor.c" 


