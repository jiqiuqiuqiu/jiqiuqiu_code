################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"D:/CCSTUDIO/ccs/tools/compiler/ti-cgt-armllvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"D:/TI_project/good_competition_v7/motor" -I"D:/TI_project/good_competition_v7/CORE" -I"D:/TI_project/good_competition_v7/RingBuffer" -I"D:/TI_project/good_competition_v7/RZ7899_MOTOR" -I"D:/TI_project/good_competition_v7/UART_redirect" -I"D:/TI_project/good_competition_v7" -I"D:/TI_project/good_competition_v7/Debug" -I"D:/CCSTUDIO/mspm0_sdk_2_04_00_06/source/third_party/CMSIS/Core/Include" -I"D:/CCSTUDIO/mspm0_sdk_2_04_00_06/source" -gdwarf-3 -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

build-1827568959: ../timx_timer_mode_pwm_edge_sleep.syscfg
	@echo 'Building file: "$<"'
	@echo 'Invoking: SysConfig'
	"D:/CCSTUDIO/ccs/utils/sysconfig_1.23.0/sysconfig_cli.bat" --script "D:/TI_project/good_competition_v7/timx_timer_mode_pwm_edge_sleep.syscfg" -o "." -s "D:/CCSTUDIO/mspm0_sdk_2_04_00_06/.metadata/product.json" -s "D:/CCSTUDIO/mspm0_sdk_2_04_00_06/.metadata/product.json" --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

device_linker.cmd: build-1827568959 ../timx_timer_mode_pwm_edge_sleep.syscfg
device.opt: build-1827568959
device.cmd.genlibs: build-1827568959
ti_msp_dl_config.c: build-1827568959
ti_msp_dl_config.h: build-1827568959
Event.dot: build-1827568959

%.o: ./%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"D:/CCSTUDIO/ccs/tools/compiler/ti-cgt-armllvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"D:/TI_project/good_competition_v7/motor" -I"D:/TI_project/good_competition_v7/CORE" -I"D:/TI_project/good_competition_v7/RingBuffer" -I"D:/TI_project/good_competition_v7/RZ7899_MOTOR" -I"D:/TI_project/good_competition_v7/UART_redirect" -I"D:/TI_project/good_competition_v7" -I"D:/TI_project/good_competition_v7/Debug" -I"D:/CCSTUDIO/mspm0_sdk_2_04_00_06/source/third_party/CMSIS/Core/Include" -I"D:/CCSTUDIO/mspm0_sdk_2_04_00_06/source" -gdwarf-3 -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

startup_mspm0g350x_ticlang.o: D:/CCSTUDIO/mspm0_sdk_2_04_00_06/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"D:/CCSTUDIO/ccs/tools/compiler/ti-cgt-armllvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"D:/TI_project/good_competition_v7/motor" -I"D:/TI_project/good_competition_v7/CORE" -I"D:/TI_project/good_competition_v7/RingBuffer" -I"D:/TI_project/good_competition_v7/RZ7899_MOTOR" -I"D:/TI_project/good_competition_v7/UART_redirect" -I"D:/TI_project/good_competition_v7" -I"D:/TI_project/good_competition_v7/Debug" -I"D:/CCSTUDIO/mspm0_sdk_2_04_00_06/source/third_party/CMSIS/Core/Include" -I"D:/CCSTUDIO/mspm0_sdk_2_04_00_06/source" -gdwarf-3 -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


