/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_0 */
#define PWM_0_INST                                                         TIMG0
#define PWM_0_INST_IRQHandler                                   TIMG0_IRQHandler
#define PWM_0_INST_INT_IRQN                                     (TIMG0_INT_IRQn)
#define PWM_0_INST_CLK_FREQ                                              1000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_0_C0_PORT                                                 GPIOA
#define GPIO_PWM_0_C0_PIN                                         DL_GPIO_PIN_12
#define GPIO_PWM_0_C0_IOMUX                                      (IOMUX_PINCM34)
#define GPIO_PWM_0_C0_IOMUX_FUNC                     IOMUX_PINCM34_PF_TIMG0_CCP0
#define GPIO_PWM_0_C0_IDX                                    DL_TIMER_CC_0_INDEX

/* Defines for PWM_1 */
#define PWM_1_INST                                                         TIMG6
#define PWM_1_INST_IRQHandler                                   TIMG6_IRQHandler
#define PWM_1_INST_INT_IRQN                                     (TIMG6_INT_IRQn)
#define PWM_1_INST_CLK_FREQ                                              1000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_1_C0_PORT                                                 GPIOB
#define GPIO_PWM_1_C0_PIN                                          DL_GPIO_PIN_2
#define GPIO_PWM_1_C0_IOMUX                                      (IOMUX_PINCM15)
#define GPIO_PWM_1_C0_IOMUX_FUNC                     IOMUX_PINCM15_PF_TIMG6_CCP0
#define GPIO_PWM_1_C0_IDX                                    DL_TIMER_CC_0_INDEX

/* Defines for PWM_2 */
#define PWM_2_INST                                                         TIMA1
#define PWM_2_INST_IRQHandler                                   TIMA1_IRQHandler
#define PWM_2_INST_INT_IRQN                                     (TIMA1_INT_IRQn)
#define PWM_2_INST_CLK_FREQ                                              1000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_2_C0_PORT                                                 GPIOB
#define GPIO_PWM_2_C0_PIN                                          DL_GPIO_PIN_4
#define GPIO_PWM_2_C0_IOMUX                                      (IOMUX_PINCM17)
#define GPIO_PWM_2_C0_IOMUX_FUNC                     IOMUX_PINCM17_PF_TIMA1_CCP0
#define GPIO_PWM_2_C0_IDX                                    DL_TIMER_CC_0_INDEX

/* Defines for PWM_MOTOR */
#define PWM_MOTOR_INST                                                     TIMA0
#define PWM_MOTOR_INST_IRQHandler                               TIMA0_IRQHandler
#define PWM_MOTOR_INST_INT_IRQN                                 (TIMA0_INT_IRQn)
#define PWM_MOTOR_INST_CLK_FREQ                                          1000000
/* GPIO defines for channel 1 */
#define GPIO_PWM_MOTOR_C1_PORT                                             GPIOB
#define GPIO_PWM_MOTOR_C1_PIN                                      DL_GPIO_PIN_9
#define GPIO_PWM_MOTOR_C1_IOMUX                                  (IOMUX_PINCM26)
#define GPIO_PWM_MOTOR_C1_IOMUX_FUNC                 IOMUX_PINCM26_PF_TIMA0_CCP1
#define GPIO_PWM_MOTOR_C1_IDX                                DL_TIMER_CC_1_INDEX




/* Defines for QEI_0 */
#define QEI_0_INST                                                         TIMG8
#define QEI_0_INST_IRQHandler                                   TIMG8_IRQHandler
#define QEI_0_INST_INT_IRQN                                     (TIMG8_INT_IRQn)
/* Pin configuration defines for QEI_0 PHA Pin */
#define GPIO_QEI_0_PHA_PORT                                                GPIOA
#define GPIO_QEI_0_PHA_PIN                                        DL_GPIO_PIN_29
#define GPIO_QEI_0_PHA_IOMUX                                      (IOMUX_PINCM4)
#define GPIO_QEI_0_PHA_IOMUX_FUNC                     IOMUX_PINCM4_PF_TIMG8_CCP0
/* Pin configuration defines for QEI_0 PHB Pin */
#define GPIO_QEI_0_PHB_PORT                                                GPIOA
#define GPIO_QEI_0_PHB_PIN                                        DL_GPIO_PIN_30
#define GPIO_QEI_0_PHB_IOMUX                                      (IOMUX_PINCM5)
#define GPIO_QEI_0_PHB_IOMUX_FUNC                     IOMUX_PINCM5_PF_TIMG8_CCP1


/* Defines for BFTM0 */
#define BFTM0_INST                                                       (TIMG7)
#define BFTM0_INST_IRQHandler                                   TIMG7_IRQHandler
#define BFTM0_INST_INT_IRQN                                     (TIMG7_INT_IRQn)
#define BFTM0_INST_LOAD_VALUE                                             (124U)
/* Defines for TIMER_0 */
#define TIMER_0_INST                                                    (TIMG12)
#define TIMER_0_INST_IRQHandler                                TIMG12_IRQHandler
#define TIMER_0_INST_INT_IRQN                                  (TIMG12_INT_IRQn)
#define TIMER_0_INST_LOAD_VALUE                                       (3199999U)



/* Defines for NFC */
#define NFC_INST                                                           UART0
#define NFC_INST_FREQUENCY                                              32000000
#define NFC_INST_IRQHandler                                     UART0_IRQHandler
#define NFC_INST_INT_IRQN                                         UART0_INT_IRQn
#define GPIO_NFC_RX_PORT                                                   GPIOB
#define GPIO_NFC_TX_PORT                                                   GPIOB
#define GPIO_NFC_RX_PIN                                            DL_GPIO_PIN_1
#define GPIO_NFC_TX_PIN                                            DL_GPIO_PIN_0
#define GPIO_NFC_IOMUX_RX                                        (IOMUX_PINCM13)
#define GPIO_NFC_IOMUX_TX                                        (IOMUX_PINCM12)
#define GPIO_NFC_IOMUX_RX_FUNC                         IOMUX_PINCM13_PF_UART0_RX
#define GPIO_NFC_IOMUX_TX_FUNC                         IOMUX_PINCM12_PF_UART0_TX
#define NFC_BAUD_RATE                                                     (9600)
#define NFC_IBRD_32_MHZ_9600_BAUD                                          (208)
#define NFC_FBRD_32_MHZ_9600_BAUD                                           (21)
/* Defines for UART_1 */
#define UART_1_INST                                                        UART1
#define UART_1_INST_FREQUENCY                                           32000000
#define UART_1_INST_IRQHandler                                  UART1_IRQHandler
#define UART_1_INST_INT_IRQN                                      UART1_INT_IRQn
#define GPIO_UART_1_RX_PORT                                                GPIOA
#define GPIO_UART_1_TX_PORT                                                GPIOA
#define GPIO_UART_1_RX_PIN                                         DL_GPIO_PIN_9
#define GPIO_UART_1_TX_PIN                                         DL_GPIO_PIN_8
#define GPIO_UART_1_IOMUX_RX                                     (IOMUX_PINCM20)
#define GPIO_UART_1_IOMUX_TX                                     (IOMUX_PINCM19)
#define GPIO_UART_1_IOMUX_RX_FUNC                      IOMUX_PINCM20_PF_UART1_RX
#define GPIO_UART_1_IOMUX_TX_FUNC                      IOMUX_PINCM19_PF_UART1_TX
#define UART_1_BAUD_RATE                                                (115200)
#define UART_1_IBRD_32_MHZ_115200_BAUD                                      (17)
#define UART_1_FBRD_32_MHZ_115200_BAUD                                      (23)
/* Defines for UART_RED */
#define UART_RED_INST                                                      UART3
#define UART_RED_INST_FREQUENCY                                         32000000
#define UART_RED_INST_IRQHandler                                UART3_IRQHandler
#define UART_RED_INST_INT_IRQN                                    UART3_INT_IRQn
#define GPIO_UART_RED_RX_PORT                                              GPIOA
#define GPIO_UART_RED_TX_PORT                                              GPIOA
#define GPIO_UART_RED_RX_PIN                                      DL_GPIO_PIN_13
#define GPIO_UART_RED_TX_PIN                                      DL_GPIO_PIN_14
#define GPIO_UART_RED_IOMUX_RX                                   (IOMUX_PINCM35)
#define GPIO_UART_RED_IOMUX_TX                                   (IOMUX_PINCM36)
#define GPIO_UART_RED_IOMUX_RX_FUNC                    IOMUX_PINCM35_PF_UART3_RX
#define GPIO_UART_RED_IOMUX_TX_FUNC                    IOMUX_PINCM36_PF_UART3_TX
#define UART_RED_BAUD_RATE                                                (9600)
#define UART_RED_IBRD_32_MHZ_9600_BAUD                                     (208)
#define UART_RED_FBRD_32_MHZ_9600_BAUD                                      (21)
/* Defines for UART_2 */
#define UART_2_INST                                                        UART2
#define UART_2_INST_FREQUENCY                                           32000000
#define UART_2_INST_IRQHandler                                  UART2_IRQHandler
#define UART_2_INST_INT_IRQN                                      UART2_INT_IRQn
#define GPIO_UART_2_RX_PORT                                                GPIOB
#define GPIO_UART_2_TX_PORT                                                GPIOB
#define GPIO_UART_2_RX_PIN                                        DL_GPIO_PIN_18
#define GPIO_UART_2_TX_PIN                                        DL_GPIO_PIN_17
#define GPIO_UART_2_IOMUX_RX                                     (IOMUX_PINCM44)
#define GPIO_UART_2_IOMUX_TX                                     (IOMUX_PINCM43)
#define GPIO_UART_2_IOMUX_RX_FUNC                      IOMUX_PINCM44_PF_UART2_RX
#define GPIO_UART_2_IOMUX_TX_FUNC                      IOMUX_PINCM43_PF_UART2_TX
#define UART_2_BAUD_RATE                                                  (9600)
#define UART_2_IBRD_32_MHZ_9600_BAUD                                       (208)
#define UART_2_FBRD_32_MHZ_9600_BAUD                                        (21)





/* Port definition for Pin Group Conveyor */
#define Conveyor_PORT                                                    (GPIOA)

/* Defines for con: GPIOA.17 with pinCMx 39 on package pin 10 */
#define Conveyor_con_PIN                                        (DL_GPIO_PIN_17)
#define Conveyor_con_IOMUX                                       (IOMUX_PINCM39)
/* Port definition for Pin Group infrared */
#define infrared_PORT                                                    (GPIOA)

/* Defines for PA27: GPIOA.27 with pinCMx 60 on package pin 31 */
#define infrared_PA27_PIN                                       (DL_GPIO_PIN_27)
#define infrared_PA27_IOMUX                                      (IOMUX_PINCM60)
/* Port definition for Pin Group RZ */
#define RZ_PORT                                                          (GPIOB)

/* Defines for PB8: GPIOB.8 with pinCMx 25 on package pin 60 */
#define RZ_PB8_PIN                                               (DL_GPIO_PIN_8)
#define RZ_PB8_IOMUX                                             (IOMUX_PINCM25)
/* Port definition for Pin Group XYZ */
#define XYZ_PORT                                                         (GPIOB)

/* Defines for X: GPIOB.3 with pinCMx 16 on package pin 51 */
#define XYZ_X_PIN                                                (DL_GPIO_PIN_3)
#define XYZ_X_IOMUX                                              (IOMUX_PINCM16)
/* Defines for Y: GPIOB.5 with pinCMx 18 on package pin 53 */
#define XYZ_Y_PIN                                                (DL_GPIO_PIN_5)
#define XYZ_Y_IOMUX                                              (IOMUX_PINCM18)
/* Defines for Z: GPIOB.7 with pinCMx 24 on package pin 59 */
#define XYZ_Z_PIN                                                (DL_GPIO_PIN_7)
#define XYZ_Z_IOMUX                                              (IOMUX_PINCM24)
/* Defines for X1: GPIOB.22 with pinCMx 50 on package pin 21 */
#define SN04_X1_PORT                                                     (GPIOB)
#define SN04_X1_PIN                                             (DL_GPIO_PIN_22)
#define SN04_X1_IOMUX                                            (IOMUX_PINCM50)
/* Defines for Y1: GPIOA.24 with pinCMx 54 on package pin 25 */
#define SN04_Y1_PORT                                                     (GPIOA)
#define SN04_Y1_PIN                                             (DL_GPIO_PIN_24)
#define SN04_Y1_IOMUX                                            (IOMUX_PINCM54)
/* Defines for Z1: GPIOB.26 with pinCMx 57 on package pin 28 */
#define SN04_Z1_PORT                                                     (GPIOB)
#define SN04_Z1_PIN                                             (DL_GPIO_PIN_26)
#define SN04_Z1_IOMUX                                            (IOMUX_PINCM57)
/* Port definition for Pin Group KEY */
#define KEY_PORT                                                         (GPIOB)

/* Defines for key_1: GPIOB.12 with pinCMx 29 on package pin 64 */
#define KEY_key_1_PIN                                           (DL_GPIO_PIN_12)
#define KEY_key_1_IOMUX                                          (IOMUX_PINCM29)
/* Defines for key_2: GPIOB.13 with pinCMx 30 on package pin 1 */
#define KEY_key_2_PIN                                           (DL_GPIO_PIN_13)
#define KEY_key_2_IOMUX                                          (IOMUX_PINCM30)
/* Defines for key_3: GPIOB.14 with pinCMx 31 on package pin 2 */
#define KEY_key_3_PIN                                           (DL_GPIO_PIN_14)
#define KEY_key_3_IOMUX                                          (IOMUX_PINCM31)
/* Defines for key_4: GPIOB.15 with pinCMx 32 on package pin 3 */
#define KEY_key_4_PIN                                           (DL_GPIO_PIN_15)
#define KEY_key_4_IOMUX                                          (IOMUX_PINCM32)
/* Defines for key_5: GPIOB.16 with pinCMx 33 on package pin 4 */
#define KEY_key_5_PIN                                           (DL_GPIO_PIN_16)
#define KEY_key_5_IOMUX                                          (IOMUX_PINCM33)

/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_0_init(void);
void SYSCFG_DL_PWM_1_init(void);
void SYSCFG_DL_PWM_2_init(void);
void SYSCFG_DL_PWM_MOTOR_init(void);
void SYSCFG_DL_QEI_0_init(void);
void SYSCFG_DL_BFTM0_init(void);
void SYSCFG_DL_TIMER_0_init(void);
void SYSCFG_DL_NFC_init(void);
void SYSCFG_DL_UART_1_init(void);
void SYSCFG_DL_UART_RED_init(void);
void SYSCFG_DL_UART_2_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
