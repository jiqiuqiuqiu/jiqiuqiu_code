################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../UART_redirect/UART_redirect.c 

C_DEPS += \
./UART_redirect/UART_redirect.d 

OBJS += \
./UART_redirect/UART_redirect.o 

OBJS__QUOTED += \
"UART_redirect\UART_redirect.o" 

C_DEPS__QUOTED += \
"UART_redirect\UART_redirect.d" 

C_SRCS__QUOTED += \
"../UART_redirect/UART_redirect.c" 


