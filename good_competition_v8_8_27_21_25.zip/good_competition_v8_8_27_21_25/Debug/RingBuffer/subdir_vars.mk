################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../RingBuffer/RingBuffer.c 

C_DEPS += \
./RingBuffer/RingBuffer.d 

OBJS += \
./RingBuffer/RingBuffer.o 

OBJS__QUOTED += \
"RingBuffer\RingBuffer.o" 

C_DEPS__QUOTED += \
"RingBuffer\RingBuffer.d" 

C_SRCS__QUOTED += \
"../RingBuffer/RingBuffer.c" 


