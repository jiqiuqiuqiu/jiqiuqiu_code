# FIXED

RingBuffer/RingBuffer.o: ../RingBuffer/RingBuffer.c \
 ../RingBuffer/RingBuffer.h
../RingBuffer/RingBuffer.h:
