#ifndef __UART_REDIRECT_H__
#define __UART_REDIRECT_H__

#include "ti_msp_dl_config.h"
#include <stdio.h>
#include <string.h>

int fputc(int ch,FILE* f);
int fputs(const char* restrict s,FILE* restrict f);
int puts(const char* _ptr);

#endif