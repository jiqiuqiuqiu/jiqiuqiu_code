#include "UART_redirect.h"

/**
  *@brief   对fputc函数的重定向
  *@param
  *@retval
  */
int fputc(int ch,FILE* f)
{
    DL_UART_Main_transmitDataBlocking(UART_RED_INST,ch);//参数根据重定向的位置编写
    return ch;
}

/**
  *@brief   对fputs函数的重定向
  *@param
  *@retval
  */
int fputs(const char* restrict s,FILE* restrict f)
{
    uint16_t i = 0;
    uint16_t len = 0;

    len = strlen(s);

    for(i = 0;i < len;i++)
    {
        DL_UART_transmitDataBlocking(UART_RED_INST,s[i]);//参数根据重定向的位置编写
    }

    return len;
}

/**
  *@brief   辅助于fputs
  *@param
  *@retval
  */
int puts(const char* _ptr)
{
    int count = fputs(_ptr,stdout);
    count += fputs("\n",stdout);
    return count;
}

/**
  *@brief   打印一个字符串
  *@param   字符串
  *@retval  无
  */
void Uart_sendString(char* string)
{
    uint32_t i = 0;

     for(i = 0;string[i] != '\0';i++)
    {
        DL_UART_Main_transmitDataBlocking(UART_RED_INST,string[i]);//参数根据重定向的位置编写
     }
}















