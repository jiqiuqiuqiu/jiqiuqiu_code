#ifndef RINGBUFFER_RINGBUFFER_H
#define RINGBUFFER_RINGBUFFER_H

#include "stdint.h"
#include "stdbool.h"

//缓冲区的性质
typedef struct
{

    uint8_t *Head;//换形首地址
    uint8_t *Tail;//换形尾地址
    uint8_t *ValidHead;//可用头地址
    uint8_t *ValidTail;//可用尾地址
    uint16_t DataSize;//总数据大小
}RingBufferTypedef;

//缓冲区的状态
typedef enum
{
    BUF_OK = 0,//没问题
    BUF_ERROR,//错误
    BUF_NULL,//缓冲区是空的
    BUF_OVERLOAD,//数据满了，或者超过指定大小
    BUF_LACK,//数据缺少
}BUFEnum;

uint8_t RingBuffer_Init(RingBufferTypedef *RingBuffer);
uint8_t RingBuffer_PushOneData_Real(RingBufferTypedef *RingBuffer,uint8_t Buf);
uint8_t RingBuffer_PopOneData(RingBufferTypedef *RingBuffer,uint8_t *Buf);
uint16_t RingBuffer_Count(RingBufferTypedef *RingBuffer);
uint8_t RingBuffer_PushArrayData_Real(RingBufferTypedef *RingBuffer,uint8_t *data,uint16_t len);
uint8_t RingBuffer_PopArrayData(RingBufferTypedef *RingBuffer,uint8_t *Buf,uint16_t len);
uint8_t RingBuffer_PeekOneNewData(RingBufferTypedef *RingBuffer,uint8_t *Buf);
uint8_t RingBuffer_PeekArrayNewData(RingBufferTypedef *RingBuffer,uint8_t *Buf,uint16_t len);


#endif //RINGBUFFER_RINGBUFFER_H