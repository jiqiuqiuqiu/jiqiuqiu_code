#include <stddef.h>
#include "RingBuffer.h"

/**
 * 循环缓存区主要有两种操作方式
 * 介绍两种的操作
 * 实时流
 * 这种方案优先保证实时性。如果buffer满了，优先丢弃老的数据，让新数据存进来
 * 存储流
 * 这种方案优先保证稳定性。如果buffer满了，舍弃最新的数据，等待老的流处理完再进新的流进行处理
 *
 */


 //@brief 缓冲区初始化

uint8_t RingBuffer_Init(RingBufferTypedef *RingBuffer)
{
    //如果缓冲区的首元素的地址是空的，返回缓冲区此时的状态是空的
    if (RingBuffer->Head == NULL)
        return BUF_NULL;

    //否则，缓冲区的首元素的地址非空
    RingBuffer->Tail = RingBuffer->Head + RingBuffer->DataSize;//将缓冲区的首元素地址向缓冲区的尾元素向后移一个缓冲区的长度
    RingBuffer->ValidHead = NULL;//清空首地址中的内容
    RingBuffer->ValidTail = NULL;//清空尾地址中的内容
    return BUF_OK;//返回状态ok
}

/**
 * @brief 压入一个数据 实时流
 * @param RingBuffer
 * @param Buf
 * @return
 */
uint8_t RingBuffer_PushOneData_Real(RingBufferTypedef *RingBuffer,uint8_t Buf)
{
    if (RingBuffer->ValidTail == NULL)
    {
        RingBuffer->ValidTail = RingBuffer->Head;
    }
    (*RingBuffer->ValidTail) = Buf;
    RingBuffer->ValidTail++;

    if (RingBuffer->ValidHead == NULL)//已经有数据加入，头可用
    {
        RingBuffer->ValidHead = RingBuffer->Head;
    }

    if (RingBuffer->ValidTail > RingBuffer->Tail)//超过最大存储返回
    {
        RingBuffer->ValidTail = RingBuffer->Head;//指针调到第一个
    }
    if (RingBuffer->ValidHead == RingBuffer->ValidTail)//如果可用头地址和尾地址一样，说明缓冲区数据已经满了，可用的头地址往后移动一格
    {
        RingBuffer->ValidHead++;
        if (RingBuffer->ValidHead > RingBuffer->Tail)
				{
            RingBuffer->ValidHead = RingBuffer->Head;
		
						RingBuffer->ValidTail = NULL;
				}
    }
    return BUF_OK;
}


/**
 * @brief 弹出一个变量
 * @param RingBuffer
 * @param Buf
 * @return
 */
uint8_t RingBuffer_PopOneData(RingBufferTypedef *RingBuffer,uint8_t *Buf)
{
    if (RingBuffer->ValidHead == NULL)
    {
        return BUF_NULL;//空的
    }
    *Buf = *(RingBuffer->ValidHead);
    RingBuffer->ValidHead++;
    if (RingBuffer->ValidHead > RingBuffer->Tail)
        RingBuffer->ValidHead = RingBuffer->Head;
    if (RingBuffer->ValidHead == RingBuffer->ValidTail)//如果等于 说明已经用完了是空的
		{
				RingBuffer->ValidHead = NULL;
				RingBuffer->ValidTail = NULL;
    }
		return BUF_OK;
}

/**
 * @brief 统计数据个数
 * @param RingBuffer
 * @return
 */
uint16_t RingBuffer_Count(RingBufferTypedef *RingBuffer)
{
    if (RingBuffer->ValidHead == NULL)
        return 0;
    if (RingBuffer->ValidHead <= RingBuffer->ValidTail)
    {
        return  (unsigned int)(RingBuffer->ValidTail - RingBuffer->ValidHead);
    }
    else
    {
        return (uint16_t)((RingBuffer->Tail - RingBuffer->ValidHead) + (RingBuffer->ValidTail-RingBuffer->Head+1));//RingBuffer->ValidTail == RingBuffer->ValidHead 的情况下为0 0本身也是一个
    }
}


/**
 * @brief 压入一组数据在队列中 覆盖
 */
uint8_t RingBuffer_PushArrayData_Real(RingBufferTypedef *RingBuffer,uint8_t *data,uint16_t len)
{
    if (len > RingBuffer->DataSize)
    {
        return BUF_OVERLOAD;
    }
    else
    {
        for (int i = 0; i < len; ++i)
        {
            RingBuffer_PushOneData_Real(RingBuffer,*data);
            data++;
        }
    }
    return BUF_OK;
}


/**
 * @brief 弹出一组数据
 * @param RingBuffer
 * @param Buf
 * @param len
 * @return BUF_LACK BUF_OK
 */
uint8_t RingBuffer_PopArrayData(RingBufferTypedef *RingBuffer,uint8_t *Buf,uint16_t len)
{
    if (len>RingBuffer_Count(RingBuffer))//超过数据量
    {
        return BUF_LACK;
    }
    for (int i = 0; i < len; ++i)
    {
        RingBuffer_PopOneData(RingBuffer,Buf);
        Buf++;
    }
    return BUF_OK;
}

/**
 * @brief 偷窥最新的一个数据，不删除
 * @param RingBuffer
 * @param Buf
 * @return
 */
uint8_t RingBuffer_PeekOneNewData(RingBufferTypedef *RingBuffer,uint8_t *Buf)
{
    uint8_t *dataAddr = NULL;
    if (RingBuffer->ValidTail == NULL) return BUF_NULL;
    dataAddr = ((RingBuffer->ValidTail)-1);
    if (dataAddr < RingBuffer->Head)
    {
        dataAddr = RingBuffer->Tail;
    }
    *Buf = *dataAddr;

    return BUF_OK;
}

/**
 * @brief 偷窥最新的一组数据，不删除
 * @param RingBuffer
 * @param Buf
 * @param len
 * @return
 */
uint8_t RingBuffer_PeekArrayNewData(RingBufferTypedef *RingBuffer,uint8_t *Buf,uint16_t len)
{
    uint8_t *dataAddr = NULL;
    if (RingBuffer->ValidTail == NULL)//数据为空
        return BUF_NULL;
    if (RingBuffer_Count(RingBuffer) > len)//数据不足
        return BUF_LACK;

    Buf += (len-1);
    dataAddr = ((RingBuffer->ValidTail)-1);

    for (uint16_t i = len;i > 0;i--)//将数据取出来
    {
        if (dataAddr < RingBuffer->Head)
        {
            dataAddr = RingBuffer->Tail;
        }
        *Buf = *dataAddr;
        dataAddr--;
        Buf--;
    }
    return BUF_OK;
}

/**
 * @brief 弹出一个最新数据
 * @param RingBuffer
 * @param Buf
 * @return
 */
uint8_t RingBuffer_PopOneNewData(RingBufferTypedef *RingBuffer,uint8_t *Buf)
{
    uint8_t *dataAddr = NULL;
    if (RingBuffer->ValidTail == NULL) return BUF_NULL;
    dataAddr = ((RingBuffer->ValidTail)-1);
    if (dataAddr < RingBuffer->Head)
    {
        dataAddr = RingBuffer->Tail;
    }
    RingBuffer->ValidHead--;
    if (RingBuffer->ValidHead < RingBuffer->Head)
    {
        RingBuffer->ValidHead =  RingBuffer->Tail;
    }
    *Buf = *dataAddr;
    if (RingBuffer->ValidHead == RingBuffer->ValidTail)//如果等于 说明已经用完了是空的
        RingBuffer->ValidTail = NULL;
    return BUF_OK;
}