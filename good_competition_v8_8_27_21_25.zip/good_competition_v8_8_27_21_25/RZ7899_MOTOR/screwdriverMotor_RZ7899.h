#ifndef SCREWDRIVERMOTOR_RZ7899_H
#define SCREWDRIVERMOTOR_RZ7899_H

#define SPEED_LOW       1
#define SPEED_MEDIUM    2
#define SPEED_HIGH      3

#include <stdint.h>
#include "GPTM0.h"
#include "MCTM0.h"
#include "motor.h"

void Interupt_motor(void);
void ScrewMotor_Init(void);
uint8_t ScrewMotor_start(uint8_t dir,uint8_t sck);
void ScrewMotor_test(void);
void ScrewMotorClockwiseStart(void);
void ScrewMotorBrake(void);
void ScrewMotorAnticlockwisetart(void);
void ScrewMotorStop(void);
uint8_t ScrewMotorStart(uint8_t dir,uint32_t sck);
void TurnScrew(void);
void ScrewMotor_test(void);

extern volatile uint8_t scrediver_speed_state;

#endif







