#include "screwdriverMotor_RZ7899.h"

volatile uint8_t scrediver_speed_state = 0; 

typedef struct 
{
	volatile uint8_t state;//状态
	volatile uint8_t dir;
	volatile uint32_t CNT;//脉冲计数
	volatile uint32_t totalCNT;//脉冲总个数

}MOTOR_STRUCT_t;

MOTOR_STRUCT_t  ScrewMotor;

//电机初始化
void ScrewMotor_Init(void)
{
	GCTM0_Init();
	DL_TimerG_stopCounter(PWM_MOTOR_INST);
	//GPTM0_GET_CNT();
}

//这里的中断放到GPTM0的文件中



//顺时针转，PB8低电平，PB9输出
void ScrewMotorClockwiseStart(void)
{
	MCTM0_EnablePWMOutput();
	//DL_TimerA_setCaptureCompareValue(PWM_MOTOR_INST,30000,DL_TIMER_CC_0_INDEX);
	DL_GPIO_clearPins(RZ_PORT, RZ_PB8_PIN);

	if(scrediver_speed_state == SPEED_HIGH)
	{
		DL_TimerA_setCaptureCompareValue(PWM_MOTOR_INST,400,GPIO_PWM_MOTOR_C1_IDX);
	}
	if(scrediver_speed_state == SPEED_MEDIUM)
	{
		DL_TimerA_setCaptureCompareValue(PWM_MOTOR_INST,250,GPIO_PWM_MOTOR_C1_IDX);
	}
	if(scrediver_speed_state == SPEED_LOW)
	{
		DL_TimerA_setCaptureCompareValue(PWM_MOTOR_INST,150,GPIO_PWM_MOTOR_C1_IDX);
	}
}

//逆时针旋转，PB9输出，PB8不输出
void ScrewMotorAnticlockwisetart(void)
{
	DL_TimerA_setCaptureCompareValue(PWM_MOTOR_INST,0,DL_TIMER_CC_0_INDEX);
	//DL_TimerA_setCaptureCompareValue(PWM_MOTOR_INST,30000,DL_TIMER_CC_1_INDEX);
}


//电机停止,PB9引脚为低电平
void ScrewMotorStop(void)
{
	MCTM0_DisablePWMOutput();
	DL_GPIO_clearPins(RZ_PORT, RZ_PB8_PIN);
	//DL_GPIO_clearPins(GPIO_PWM_MOTOR_C0_PORT, GPIO_PWM_MOTOR_C0_PIN);
	DL_GPIO_clearPins(GPIO_PWM_MOTOR_C1_PORT, GPIO_PWM_MOTOR_C1_PIN);
}

//电机刹车，引脚为高电平
void ScrewMotorBrake(void)
{
	MCTM0_DisablePWMOutput();
	DL_GPIO_setPins(RZ_PORT, RZ_PB8_PIN);
	//DL_GPIO_setPins(GPIO_PWM_MOTOR_C0_PORT, GPIO_PWM_MOTOR_C0_PIN);
}

//转动螺丝刀，设置重装载值
void TurnScrew(void)
{
	//DL_TimerG_setLoadValue(QEI_0_INST,10000);
	ScrewMotorClockwiseStart();
	//DL_TimerG_setTimerCount(QEI_0_INST ,10000);
}


//这个函数好像没用到
uint8_t ScrewMotorStart(uint8_t dir,uint32_t sck)
{
	if(ScrewMotor.state != 0)
	{
		return ERROR;						//如果电机已在运行，直接返回错误
	}
	ScrewMotor.totalCNT = sck;//脉冲总个数

	ScrewMotor.dir = dir;
	
	if(dir == 1)//顺时针
	{
		DL_Timer_setTimerCount(QEI_0_INST,0);//清除定时器的计数
		if(ScrewMotor.totalCNT  > 0xffff)
		{
			DL_Timer_setLoadValue(QEI_0_INST, 0xffff);
		}
		else
		{
			DL_Timer_setLoadValue(QEI_0_INST, sck);
		}
		ScrewMotorClockwiseStart();
	}
	else//逆时针
	{
		DL_Timer_setTimerCount(QEI_0_INST,sck);//清除定时器的计数
		if(ScrewMotor.totalCNT  > 0xffff)
		{
			DL_Timer_setLoadValue(QEI_0_INST, 0x01);
		}
		else
		{
			DL_Timer_setLoadValue(QEI_0_INST, 0xffff-sck);
		}
		ScrewMotorAnticlockwisetart();
	}
return SUCCESS;
}

//螺丝刀测试代码
void ScrewMotor_test(void)
{
	DL_Timer_setLoadValue(QEI_0_INST,60000);//8000
	uint16_t i =5000;
	while(i--);
	ScrewMotorClockwiseStart();
}
