#ifndef _GPTM0_H_
#define _GPTM0_H_

#include "ti_msp_dl_config.h"
#include "screwdriverMotor_RZ7899.h"
#include "stdint.h"

void GCTM0_Init(void);
// void GPTM0_GET_CNT(void);
// int32_t get_QEI_count(void);


int32_t GPTM0_GetPWMCount(void);
void GPTM0_TIMER_0_Init(void);

extern volatile int32_t QEI_count;  //当前编码定时器的总计数值
extern volatile int32_t PWM_Count;
extern volatile int32_t PWMNumber;

#endif