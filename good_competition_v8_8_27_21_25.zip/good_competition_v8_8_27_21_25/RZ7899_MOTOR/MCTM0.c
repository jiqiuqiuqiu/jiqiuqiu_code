#include "MCTM0.h"

uint32_t Period_MCT = 60000;

//定时器初始化设置
void MCTM0_Configuration(void)
{
    MCTM0_DisablePWMOutput();
}

//设置频率，也就是重装载值
void MCTM0_SetFrequency(uint32_t Freq)
{
    Period_MCT = PWM_MOTOR_INST_CLK_FREQ/Freq;
    DL_Timer_setLoadValue(PWM_MOTOR_INST, Period_MCT);
}
//PB8的占空比设置
void MCTM0_PB8_SetOnduty(float Duty1)
{
    uint32_t CompareValue1;
    CompareValue1 = Period_MCT - Period_MCT*Duty1;
    DL_TimerG_setCaptureCompareValue(PWM_MOTOR_INST, CompareValue1, DL_TIMER_CC_0_INDEX);
}
//开启PWM输出
void MCTM0_EnablePWMOutput(void)
{
    DL_TimerG_startCounter(PWM_MOTOR_INST);
}
//禁止PWM输出
void MCTM0_DisablePWMOutput(void)
{
    DL_TimerG_stopCounter(PWM_MOTOR_INST);
}

// //设置PB9占空比
// void MCTM0_PB9_SetOnduty(float Duty2)
// {
//     uint32_t CompareValue2;
//     CompareValue2 = Period_MCT - Period_MCT*Duty2;
//     DL_TimerG_setCaptureCompareValue(PWM_MOTOR_INST, CompareValue2, DL_TIMER_CC_1_INDEX);
// }


//设置PWM的占空比
void MCTM0_PB9_setduty(float Duty)
{
    //初始化Capture_Compare_Value
    uint32_t Capture_Compare_Value = 0;

    //Capture_Compare_Value = 周期-周期*占空比
    Capture_Compare_Value = 500 - 500 * Duty;

    //根据不同通道调用DL_Timerx_setCaptureCompareValue();函数设置Capture_Compare_Value
    DL_TimerA_setCaptureCompareValue(PWM_MOTOR_INST,Capture_Compare_Value,GPIO_PWM_MOTOR_C1_IDX);
}
