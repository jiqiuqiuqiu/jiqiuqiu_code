#ifndef __MCTM0_H
#define __MCTM0_H

#include "ti_msp_dl_config.h"

void MCTM0_Configuration(void);
void MCTM0_SetFrequency(uint32_t Freq);
void MCTM0_PB8_SetOnduty(float Duty1);
void MCTM0_EnablePWMOutput(void);
void MCTM0_DisablePWMOutput(void);
void MCTM0_PB9_setduty(float Duty);

#endif