#include "GPTM0.h"

volatile int32_t PWMNumber = 0;//PWM计数
volatile int32_t QEI_count = 0;  //当前编码定时器的总计数值
volatile int32_t QEI_encount = 0; //定时器溢出次数
volatile int32_t PWM_Count = 0;

//读取编码器引脚1的电平
uint8_t GPTM0_ReadEncorder_1Pin(void)
{
    if(DL_GPIO_readPins(GPIO_QEI_0_PHA_PORT,GPIO_QEI_0_PHA_PIN))
    {
        return 1;
    }
    return 0;
}


//读取编码器引脚2的电平
uint8_t GPTM0_ReadEncorder_2Pin(void)
{
    if(DL_GPIO_readPins(GPIO_QEI_0_PHB_PORT,GPIO_QEI_0_PHB_PIN))
    {
        return 1;
    }
    return 0;
}

//编码器初始化函数
void GCTM0_Init(void)
{
    //DL_TimerG_enableInterrupt(QEI_0_INST,DL_TIMER_IIDX_ZERO);
    NVIC_EnableIRQ(QEI_0_INST_INT_IRQN);
    DL_TimerG_startCounter(QEI_0_INST);
}


void QEI_0_INST_IRQHandler(void)
{
    switch (DL_TimerG_getPendingInterrupt(QEI_0_INST)) 
    {
        case DL_TIMER_IIDX_CC0_DN:
            DL_TimerG_clearInterruptStatus(QEI_0_INST,DL_TIMER_IIDX_CC0_DN);
            if(GPTM0_ReadEncorder_2Pin() == 1)
            {
                QEI_count++;
            }
            break;
        case DL_TIMER_IIDX_CC0_UP:
            DL_TimerG_clearInterruptStatus(QEI_0_INST,DL_TIMER_IIDX_CC0_UP);
            if(GPTM0_ReadEncorder_2Pin() == 1)
            {
                QEI_count--;
            }
            break;
        case DL_TIMER_IIDX_CC1_DN:
            DL_TimerG_clearInterruptStatus(QEI_0_INST,DL_TIMER_IIDX_CC1_DN);
            if(GPTM0_ReadEncorder_1Pin() == 0)
            {
                QEI_count++;
            }
            break;
        case DL_TIMER_IIDX_CC1_UP:
            DL_TimerG_clearInterruptStatus(QEI_0_INST,DL_TIMER_IIDX_CC1_UP);
            if(GPTM0_ReadEncorder_1Pin() == 0)
            {
                QEI_count--;
            }
            break;
        default:
            break;
    }
}

int32_t GPTM0_GetPWMCount(void)
{
    int32_t temp = 0;

    PWM_Count = QEI_count;
    temp = PWM_Count; 

    QEI_count = 0;
    PWM_Count = 0;

    return temp;
}



// //获取脉冲数,QEI默认是4倍频
// void GPTM0_GET_CNT(void)
// {
//     QEI_count = DL_TimerG_getTimerCount(QEI_0_INST) + QEI_encount* DL_TimerG_getLoadValue(QEI_0_INST);
//     PWM_Count = QEI_count/4;
// }


// int32_t get_QEI_count(void)
// {
//     return QEI_count;
// }


/**********Timer_0函数*********/

//初始化函数
void GPTM0_TIMER_0_Init(void)
{
    DL_TimerG_startCounter(TIMER_0_INST);
    NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
}

//中断
//测速（1s）
void TIMER_0_INST_IRQHandler(void)
{   
    if(DL_TimerG_getPendingInterrupt(TIMER_0_INST))//如果中断挂起
    {   
        if(DL_TIMERG_IIDX_ZERO)//如果是0事件引起的挂起
        {
            DL_TimerG_clearInterruptStatus(TIMER_0_INST,DL_TIMERG_IIDX_ZERO);//TimerG因0事件挂起的中断状态复位
            PWMNumber = GPTM0_GetPWMCount();
            //printf("%d\r\n",PWMNumber);
        }  
    }
} 


























