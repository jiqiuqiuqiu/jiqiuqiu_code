# -*- coding: utf-8 -*-
import argparse
import json
import os
import time

import cv2
import numpy as np


def normalize_camera_id(camera_id):
    camera_id = str(camera_id).strip()
    if camera_id.isdigit():
        return int(camera_id)
    return camera_id


def build_object_points(cols, rows, square_size):
    points = []
    for row in range(rows):
        for col in range(cols):
            points.append([col * square_size, row * square_size])
    return np.array(points, dtype=np.float32)


def save_config(path, homography, cols, rows, square_size, samples):
    config = {
        "enabled": True,
        "description": "image pixel to chessboard plane coordinate",
        "inner_corners": [cols, rows],
        "square_size": square_size,
        "samples": samples,
        "homography": homography.tolist(),
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)


def main():
    parser = argparse.ArgumentParser(description="Create chessboard coordinate calibration")
    parser.add_argument("--camera", default="/dev/video52")
    parser.add_argument("--cols", type=int, default=9, help="inner corners per row")
    parser.add_argument("--rows", type=int, default=6, help="inner corners per column")
    parser.add_argument("--square-size", type=float, default=40.0, help="output coordinate units per square")
    parser.add_argument("--samples", type=int, default=20)
    parser.add_argument("--output", default="chessboard_calibration.json")
    parser.add_argument("--no-window", action="store_true")
    args = parser.parse_args()

    camera_id = normalize_camera_id(args.camera)
    capture = cv2.VideoCapture(camera_id, cv2.CAP_V4L2)
    if not capture.isOpened() and isinstance(camera_id, str) and camera_id.startswith("/dev/video"):
        capture.release()
        try:
            capture = cv2.VideoCapture(int(camera_id.replace("/dev/video", "", 1)), cv2.CAP_V4L2)
        except ValueError:
            pass

    if not capture.isOpened():
        raise RuntimeError("Cannot open camera: %s" % args.camera)

    capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc("M", "J", "P", "G"))
    capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    capture.set(cv2.CAP_PROP_FPS, 30)

    pattern_size = (args.cols, args.rows)
    collected = []
    print("Place the chessboard flat on the work plane.")
    print("Need %d stable samples. Press q to quit." % args.samples)

    try:
        while len(collected) < args.samples:
            ret, frame = capture.read()
            if not ret or frame is None:
                time.sleep(0.02)
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            found, corners = cv2.findChessboardCorners(gray, pattern_size)
            if found:
                criteria = (
                    cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,
                    30,
                    0.001,
                )
                corners = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
                collected.append(corners.reshape(-1, 2))
                cv2.drawChessboardCorners(frame, pattern_size, corners, found)
                print("Captured chessboard sample %d/%d" % (len(collected), args.samples))
                time.sleep(0.12)

            if not args.no_window:
                cv2.imshow("chessboard calibration", frame)
                key = cv2.waitKey(1) & 0xFF
                if key == ord("q"):
                    break

        if len(collected) < 4:
            raise RuntimeError("Not enough chessboard samples")

        image_points = np.mean(np.array(collected, dtype=np.float32), axis=0)
        object_points = build_object_points(args.cols, args.rows, args.square_size)
        homography, _ = cv2.findHomography(image_points, object_points, 0)
        if homography is None:
            raise RuntimeError("Failed to compute homography")

        if os.path.isabs(args.output):
            output_path = args.output
        else:
            output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), args.output)
        save_config(output_path, homography.astype(float), args.cols, args.rows, args.square_size, len(collected))
        print("Calibration saved: %s" % output_path)
    finally:
        capture.release()
        if not args.no_window:
            cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
