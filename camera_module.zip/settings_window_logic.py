from PyQt5.QtWidgets import QDialog, QMessageBox
from PyQt5.uic import loadUi
from PyQt5.QtCore import pyqtSignal
import json
import os

class SettingsWindow(QDialog):
    settings_changed = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        loadUi("settings_window.ui", self)

        if hasattr(self, 'btn_ok'):
            self.btn_ok.clicked.connect(self.save_and_show_message)
        if hasattr(self, 'btn_cancel'):
            self.btn_cancel.clicked.connect(self.reject)
        self.load_settings()

    def save_and_show_message(self):
        if self.save_settings():
            self.settings_changed.emit(self.get_settings())
            QMessageBox.information(self, "成功", "参数已发送并保存")
            self.accept()

    def save_settings(self):
        try:
            config = {
                "image_height": int(self.get_text_value('edit_image_height', '1280')),
                "image_width": int(self.get_text_value('edit_image_width', '720')),
                "real_height": float(self.get_text_value('edit_real_height', '26.48')),
                "real_width": float(self.get_text_value('edit_real_width', '15.75')),
                "offset_height": float(self.get_text_value('edit_offset_height', '3.50')),
                "offset_width": float(self.get_text_value('edit_offset_width', '3.59')),
            }

            with open("measure_config.json", "w", encoding="utf-8") as f:
                json.dump(config, f, indent=4, ensure_ascii=False)

            print("测量参数已保存:", config)
            return True

        except ValueError:
            QMessageBox.warning(self, "输入错误", "请输入有效的数字")
            return False
        except Exception as e:
            QMessageBox.warning(self, "保存失败", f"保存配置失败：{str(e)}")
            return False

    def get_text_value(self, control_name, default_value):
        if hasattr(self, control_name):
            text = getattr(self, control_name).text()
            if text.strip():
                return text
        return default_value

    def get_settings(self):
        return {
            "image_height": int(self.get_text_value('edit_image_height', '1280')),
            "image_width": int(self.get_text_value('edit_image_width', '720')),
            "real_height": float(self.get_text_value('edit_real_height', '26.48')),
            "real_width": float(self.get_text_value('edit_real_width', '15.75')),
            "offset_height": float(self.get_text_value('edit_offset_height', '3.50')),
            "offset_width": float(self.get_text_value('edit_offset_width', '3.59')),
        }

    def load_settings(self):
        if os.path.exists("measure_config.json"):
            try:
                with open("measure_config.json", "r", encoding="utf-8") as f:
                    config = json.load(f)
                    self.set_text_value('edit_image_height', config.get("image_height", "1280"))
                    self.set_text_value('edit_image_width', config.get("image_width", "720"))
                    self.set_text_value('edit_real_height', config.get("real_height", "26.48"))
                    self.set_text_value('edit_real_width', config.get("real_width", "15.75"))
                    self.set_text_value('edit_offset_height', config.get("offset_height", "3.50"))
                    self.set_text_value('edit_offset_width', config.get("offset_width", "3.59"))
                    print("已加载测量参数配置")
            except Exception as e:
                print(f"加载配置失败: {e}")

    def set_text_value(self, control_name, value):
        if hasattr(self, control_name):
            getattr(self, control_name).setText(str(value))