import json
import os

import cv2
import numpy as np


DEFAULT_CALIBRATION_FILE = "chessboard_calibration.json"


class CoordinateCalibrator:
    def __init__(self, config_path=DEFAULT_CALIBRATION_FILE):
        self.config_path = config_path
        self.enabled = False
        self.homography = None
        self.description = ""
        self.load()

    def load(self):
        if not os.path.exists(self.config_path):
            return False

        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                config = json.load(f)

            matrix = np.array(config.get("homography", []), dtype=np.float32)
            if matrix.shape != (3, 3):
                print("Calibration ignored: invalid homography shape")
                return False

            self.homography = matrix
            self.enabled = bool(config.get("enabled", True))
            self.description = str(config.get("description", ""))
            if self.enabled:
                print("Chessboard calibration enabled: %s" % self.config_path)
            return self.enabled
        except Exception as e:
            print("Calibration load failed: %s" % e)
            self.enabled = False
            self.homography = None
            return False

    def apply_points(self, holes):
        holes = list(holes or [])
        if not self.enabled or self.homography is None:
            return holes

        if not holes:
            return holes

        points = np.array([[float(hole[0]), float(hole[1])] for hole in holes], dtype=np.float32)
        points = points.reshape(-1, 1, 2)
        mapped = cv2.perspectiveTransform(points, self.homography).reshape(-1, 2)

        calibrated = []
        for index, point in enumerate(mapped):
            x = int(round(float(point[0])))
            y = int(round(float(point[1])))
            x = max(0, min(x, 0xFFFF))
            y = max(0, min(y, 0xFFFF))
            if len(holes[index]) >= 3:
                calibrated.append((x, y, holes[index][2]))
            else:
                calibrated.append((x, y))

        return calibrated
