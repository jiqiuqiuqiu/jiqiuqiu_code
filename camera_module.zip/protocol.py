from dataclasses import dataclass


UPPER_HEADER = bytes((0xA8, 0x8A))
LOWER_HEADER = bytes((0xA9, 0x9A))
FRAME_TAIL = 0xFF


class ProtocolError(ValueError):
    pass


@dataclass(frozen=True)
class SerialFrame:
    header: bytes
    command: int
    data: bytes
    crc: int
    raw: bytes


def crc8(data):
    crc = 0x00
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) & 0xFF) ^ 0x07
            else:
                crc = (crc << 1) & 0xFF
    return crc


def build_frame(header, command, data=b""):
    data = bytes(data)
    if len(header) != 2:
        raise ProtocolError("header must be 2 bytes")
    if not 0 <= command <= 0xFF:
        raise ProtocolError("command must be one byte")
    if len(data) > 0xFF:
        raise ProtocolError("data is too long")

    body = bytes((command, len(data))) + data
    return bytes(header) + body + bytes((crc8(body), FRAME_TAIL))


def parse_frame(raw, expected_header=None):
    raw = bytes(raw)
    if len(raw) < 6:
        raise ProtocolError("frame is too short")

    header = raw[:2]
    if expected_header is not None and header != bytes(expected_header):
        raise ProtocolError("unexpected frame header")

    command = raw[2]
    data_len = raw[3]
    expected_len = 2 + 1 + 1 + data_len + 1 + 1
    if len(raw) != expected_len:
        raise ProtocolError("frame length mismatch")
    if raw[-1] != FRAME_TAIL:
        raise ProtocolError("invalid frame tail")

    data = raw[4 : 4 + data_len]
    received_crc = raw[-2]
    body = raw[2 : 4 + data_len]
    calculated_crc = crc8(body)
    if received_crc != calculated_crc:
        raise ProtocolError(
            "crc mismatch: received 0x%02X, calculated 0x%02X"
            % (received_crc, calculated_crc)
        )

    return SerialFrame(
        header=header,
        command=command,
        data=data,
        crc=received_crc,
        raw=raw,
    )


def pop_frame(buffer, expected_headers):
    headers = tuple(bytes(header) for header in expected_headers)

    while len(buffer) >= 2:
        indexes = [buffer.find(header) for header in headers]
        indexes = [index for index in indexes if index >= 0]
        if not indexes:
            del buffer[:-1]
            return None

        first = min(indexes)
        if first:
            del buffer[:first]

        if len(buffer) < 4:
            return None

        data_len = buffer[3]
        total_len = 2 + 1 + 1 + data_len + 1 + 1
        if len(buffer) < total_len:
            return None

        raw = bytes(buffer[:total_len])
        try:
            frame = parse_frame(raw)
        except ProtocolError:
            del buffer[0]
            continue

        del buffer[:total_len]
        return frame


def hex_text(data):
    return " ".join("%02X" % byte for byte in data)
