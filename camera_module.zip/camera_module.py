import cv2
import numpy as np
import time
import gc
import threading
from PyQt5.QtCore import QThread, pyqtSignal, Qt
from PyQt5.QtGui import QImage, QPixmap

try:
    from rknnlite.api import RKNNLite

    RKNN_AVAILABLE = True
except ImportError:
    RKNN_AVAILABLE = False
    print("警告: RKNN Lite 未安装，请运行: pip install rknn_toolkit_lite2 --break-system-packages")


class InferenceThread(QThread):
    frame_ready = pyqtSignal(np.ndarray, list)

    def __init__(self, camera_id="/dev/video52", model_path="besthole_rv1126b.rknn", use_npu=True):
        super().__init__()
        self.camera_id = self._normalize_camera_id(camera_id)
        self.model_path = model_path
        self.use_npu = use_npu
        self.running = True
        self.capture = None
        self.rknn_lite = None
        self.class_names = ["thhole", "ahhole"]
        self.conf_threshold = 0.5
        self.target_fps = 30
        self.latest_frame = None
        self.latest_frame_id = 0
        self.latest_detections = []
        self.frame_lock = threading.Lock()
        self.detection_lock = threading.Lock()
        self.inference_worker = None

        if RKNN_AVAILABLE and self.use_npu:
            print(f"加载 RKNN 模型: {model_path}")
            try:
                self.rknn_lite = RKNNLite()

                ret = self.rknn_lite.load_rknn(model_path)
                if ret != 0:
                    print(f"加载模型失败，错误码: {ret}")
                    self.rknn_lite = None
                else:
                    ret = self.rknn_lite.init_runtime()
                    if ret != 0:
                        print(f"初始化 NPU 失败，错误码: {ret}")
                        self.rknn_lite = None
                    else:
                        print("RKNN 模型加载成功，NPU 已启用")
            except Exception as e:
                print(f"RKNN 初始化异常: {e}")
                self.rknn_lite = None
        else:
            print("RKNN 未启用（CPU 模式）")

    @staticmethod
    def _normalize_camera_id(camera_id):
        if isinstance(camera_id, str):
            camera_id = camera_id.strip()
            if camera_id.isdigit():
                return int(camera_id)
        return camera_id

    def _create_capture(self):
        capture = cv2.VideoCapture(self.camera_id, cv2.CAP_V4L2)
        if capture.isOpened():
            return capture

        if isinstance(self.camera_id, str) and self.camera_id.startswith("/dev/video"):
            capture.release()
            try:
                video_index = int(self.camera_id.replace("/dev/video", "", 1))
            except ValueError:
                return capture
            return cv2.VideoCapture(video_index, cv2.CAP_V4L2)

        return capture

    def _run_inference(self, frame):
        h, w = frame.shape[:2]

        img = cv2.resize(frame, (640, 640))
        img = img.astype(np.float32) / 255.0
        img = np.expand_dims(img, axis=0)

        detections = []
        if self.rknn_lite is None:
            return detections

        outputs = self.rknn_lite.inference(inputs=[img])
        if not outputs or len(outputs) == 0:
            return detections

        pred = outputs[0][0]

        x_scale = w / 640.0
        y_scale = h / 640.0

        for i in range(pred.shape[1]):
            cx = pred[0, i]
            cy = pred[1, i]
            bw = pred[2, i]
            bh = pred[3, i]
            conf = pred[4, i]
            cls_id = int(pred[5, i])

            if conf < self.conf_threshold:
                continue

            x1 = int((cx - bw / 2) * x_scale)
            y1 = int((cy - bh / 2) * y_scale)
            x2 = int((cx + bw / 2) * x_scale)
            y2 = int((cy + bh / 2) * y_scale)

            x1 = max(0, min(x1, w))
            y1 = max(0, min(y1, h))
            x2 = max(0, min(x2, w))
            y2 = max(0, min(y2, h))

            if x1 < x2 and y1 < y2:
                detections.append((x1, y1, x2, y2, cls_id, conf))

        return detections

    def _inference_loop(self):
        last_frame_id = -1

        while self.running:
            with self.frame_lock:
                if self.latest_frame is None or self.latest_frame_id == last_frame_id:
                    frame = None
                else:
                    frame = self.latest_frame.copy()
                    last_frame_id = self.latest_frame_id

            if frame is None:
                time.sleep(0.005)
                continue

            try:
                detections = self._run_inference(frame)
            except Exception as e:
                print(f"推理错误: {e}")
                import traceback
                traceback.print_exc()
                time.sleep(0.02)
                continue

            with self.detection_lock:
                self.latest_detections = detections

    def run(self):
        self.capture = self._create_capture()
        if not self.capture.isOpened():
            print(f"无法打开摄像头 {self.camera_id}")
            return

        self.capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        self.capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
        self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.capture.set(cv2.CAP_PROP_FPS, self.target_fps)

        time.sleep(0.5)
        print("摄像头已打开")

        if self.rknn_lite is not None:
            self.inference_worker = threading.Thread(target=self._inference_loop, daemon=True)
            self.inference_worker.start()

        frame_interval = 1.0 / self.target_fps
        next_frame_time = time.time()

        while self.running:
            ret, frame = self.capture.read()
            if not ret or frame is None:
                time.sleep(0.005)
                continue

            with self.frame_lock:
                self.latest_frame = frame.copy()
                self.latest_frame_id += 1

            with self.detection_lock:
                detections = list(self.latest_detections)

            self.frame_ready.emit(frame, detections)

            next_frame_time += frame_interval
            sleep_time = next_frame_time - time.time()
            if sleep_time > 0:
                time.sleep(sleep_time)
            else:
                next_frame_time = time.time()

        if self.inference_worker is not None:
            self.inference_worker.join(timeout=1.0)
            self.inference_worker = None

    def stop(self):
        print("正在停止推理线程")
        self.running = False
        if not self.wait(2000):
            print("线程未能在 2 秒内退出")
        if self.capture:
            self.capture.release()
            self.capture = None
        if self.rknn_lite:
            try:
                self.rknn_lite.release()
            except:
                pass
            self.rknn_lite = None
        gc.collect()
        print("推理线程已停止")


class CameraModule:
    def __init__(self, label_camera, coordinate_callback=None):
        self.label_camera = label_camera
        self.inference_thread = None
        self.coordinate_callback = coordinate_callback
        self.latest_hole_center = None

    def open_camera(self, camera_id="/dev/video52", model_path="besthole_rv1126b.rknn", use_npu=True):
        if self.inference_thread is not None:
            self.close_camera()

        self.inference_thread = InferenceThread(camera_id, model_path, use_npu)
        self.inference_thread.frame_ready.connect(self.update_display)
        self.inference_thread.start()
        print(f"摄像头 {camera_id} 已启动")

    def update_display(self, frame, detections):
        # 打印原始摄像头帧分辨率
        orig_h, orig_w = frame.shape[:2]
        print(f"【原始相机帧分辨率】宽:{orig_w} 高:{orig_h}")
    
        best_detection = None
    
        for (x1, y1, x2, y2, cls_id, conf) in detections:
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            center_x = int((x1 + x2) / 2)
            center_y = int((y1 + y2) / 2)
            cv2.circle(frame, (center_x, center_y), 4, (0, 0, 255), -1)
    
            if cls_id < len(self.inference_thread.class_names):
                label = f"{self.inference_thread.class_names[cls_id]} {conf:.2f}"
            else:
                label = f"class_{cls_id} {conf:.2f}"
    
            cv2.putText(
                frame,
                label,
                (x1, y1 - 5),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 255, 255),
                2,
            )
    
            if best_detection is None or conf > best_detection[5]:
                best_detection = (x1, y1, x2, y2, cls_id, conf)
    
        if best_detection is not None:
            x1, y1, x2, y2, _, conf = best_detection
            center = (int((x1 + x2) / 2), int((x1 + x2) / 2), float(conf))
            self.latest_hole_center = center
            if self.coordinate_callback is not None:
                self.coordinate_callback(*center)
    
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        height, width, channel = rgb_frame.shape
        bytes_per_line = channel * width
        qt_image = QImage(rgb_frame.data, width, height, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(qt_image).scaled(
            self.label_camera.size(),
            Qt.KeepAspectRatio,
            Qt.FastTransformation,
        )
    
        # 新增：打印UI上实际显示的图片分辨率
        disp_w = pixmap.width()
        disp_h = pixmap.height()
        label_w = self.label_camera.width()
        label_h = self.label_camera.height()
        print(f"【QLabel控件尺寸】宽:{label_w} 高:{label_h}")
        print(f"【UI界面显示图片Pixmap分辨率】宽:{disp_w} 高:{disp_h}\n")
    
        if hasattr(self.label_camera, "set_video_pixmap"):
            self.label_camera.set_video_pixmap(pixmap)
        else:
            self.label_camera.setPixmap(pixmap)

    def close_camera(self):
        print("正在关闭摄像头模块...")
        if self.inference_thread:
            self.inference_thread.stop()
            self.inference_thread = None
        self.label_camera.clear()
        print("摄像头模块已关闭")
