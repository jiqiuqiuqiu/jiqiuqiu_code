from PyQt5.QtWidgets import QDialog
from PyQt5.uic import loadUi
from PyQt5.QtCore import pyqtSignal


class SpeedWindow(QDialog):
    speed_selected = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        loadUi("luosiji_yunxingsudu.ui", self)

        self.pushButton.clicked.connect(lambda: self.select_speed(1))
        self.pushButton_2.clicked.connect(lambda: self.select_speed(2))
        self.pushButton_3.clicked.connect(lambda: self.select_speed(3))
        self.btn_cancel_speed.clicked.connect(self.reject)

    def select_speed(self, level):
        self.speed_selected.emit(level)
        self.accept()
