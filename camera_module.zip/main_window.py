import sys
import os
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtGui import QPainter
from PyQt5.QtWidgets import QLabel, QMainWindow, QMessageBox
from PyQt5.uic import loadUi
from camera_module import CameraModule
from ui_serial import SerialModule
from settings_window_logic import SettingsWindow
from torque_window import TorqueWindow
from speed_window import SpeedWindow


class VideoLabel(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._video_pixmap = None

    def set_video_pixmap(self, pixmap):
        self._video_pixmap = pixmap
        self.update()

    def clear(self):
        self._video_pixmap = None
        super().clear()

    def sizeHint(self):
        return QSize(1, 1)

    def minimumSizeHint(self):
        return QSize(1, 1)

    def paintEvent(self, event):
        super().paintEvent(event)
        if self._video_pixmap is None or self._video_pixmap.isNull():
            return

        rect = self.contentsRect()
        x = rect.x() + (rect.width() - self._video_pixmap.width()) // 2
        y = rect.y() + (rect.height() - self._video_pixmap.height()) // 2
        painter = QPainter(self)
        painter.drawPixmap(x, y, self._video_pixmap)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi("main.ui", self)
        self.replace_camera_label()
        self.latest_screw_hole = None
        self.machine_running = False
        self.pending_coordinate_send = False
        

        # 扭矩调节按钮
        self.torque_adjust.clicked.connect(self.open_torque_window)
        # 速度调节按钮
        self.speed_adjust.clicked.connect(self.open_speed_window)
        self.start_detection.clicked.connect(self.start_detection_flow)
        self.confirm_sending.clicked.connect(self.send_latest_screw_hole)

        # 串口模块
        self.serial_tool = SerialModule(self)
        self.btn_refreshSerial.clicked.connect(self.serial_tool.refresh_serial_ports)
        self.serial_tool.refresh_serial_ports()
        self.pushButton_connect.clicked.connect(self.serial_tool.connect_serial)
        self.time_same.clicked.connect(self.serial_tool.send_time_sync)
        self.open_screw_machine.clicked.connect(self.toggle_screw_machine)
        self.rush_screw_machine.clicked.connect(self.serial_tool.send_handshake)

        self.settings_window = None
        self.parameter_settings.clicked.connect(self.open_settings)

        # 摄像头不自动打开，等点击按钮
        self.camera = None
        self.open_camera.clicked.connect(self.on_open_camera_clicked)
        print("程序已启动，摄像头未打开，请点击'打开摄像头'按钮")

        #自适应屏幕
        self.showMaximized()


    def replace_camera_label(self):
        old_label = self.label_camera
        parent = old_label.parent()
        layout = parent.layout() if parent is not None else None

        video_label = VideoLabel(parent)
        video_label.setObjectName(old_label.objectName())
        video_label.setStyleSheet(old_label.styleSheet())
        video_label.setText(old_label.text())
        video_label.setAlignment(Qt.AlignCenter)
        video_label.setScaledContents(False)
        video_label.setSizePolicy(old_label.sizePolicy())
        video_label.setMinimumSize(old_label.minimumSize())
        video_label.setMaximumSize(old_label.maximumSize())
        video_label.setGeometry(old_label.geometry())

        if layout is not None:
            layout.replaceWidget(old_label, video_label)

        old_label.setParent(None)
        old_label.deleteLater()
        self.label_camera = video_label


    def on_open_camera_clicked(self):
        if self.camera is not None:
            print("摄像头已打开，无需重复操作")
            return
        
        print("正在打开摄像头...")
        self.camera = CameraModule(self.label_camera, self.on_screw_hole_detected)

        # 获取当前脚本所在目录
        current_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(current_dir, "besthole_rv1126b.rknn")

        self.camera.open_camera(
            camera_id="/dev/video52",
            model_path=model_path,
            use_npu=True # 使用 NPU
        )

        self.open_camera.setText("摄像头已打开")
        self.open_camera.setStyleSheet("color: green; font-size: 26px; font-weight: bold;")
        print("摄像头已打开")

    def on_screw_hole_detected(self, x, y, conf):
        previous = self.latest_screw_hole
        self.latest_screw_hole = (x, y, conf)
        if (
            previous is None
            or abs(previous[0] - x) > 2
            or abs(previous[1] - y) > 2
        ):
            print(f"识别到螺丝孔中心坐标: x={x}, y={y}, conf={conf:.2f}")

        if self.pending_coordinate_send and self.serial_tool.is_handshake_ok():
            self.pending_coordinate_send = False
            self.send_latest_screw_hole()

    def send_latest_screw_hole(self):
        if self.latest_screw_hole is None:
            QMessageBox.warning(self, "提示", "还没有识别到螺丝孔坐标")
            return

        x, y, conf = self.latest_screw_hole
        if self.serial_tool.send_coordinate(x, y):
            print(f"已发送螺丝孔坐标: x={x}, y={y}, conf={conf:.2f}")

    def request_coordinate_send_from_lower(self):
        if self.camera is None:
            self.on_open_camera_clicked()

        if self.latest_screw_hole is None:
            self.pending_coordinate_send = True
            print("收到下位机开始识别指令，等待识别到坐标后自动发送")
            return

        self.pending_coordinate_send = False
        self.send_latest_screw_hole()

    def on_lower_stop_requested(self):
        self.pending_coordinate_send = False
        self.machine_running = False
        self.open_screw_machine.setText("打开螺丝机")
        self.start_detection.setText("开始检测")

    def start_detection_flow(self):
        if self.camera is None:
            self.on_open_camera_clicked()

        if self.serial_tool.send_start_run():
            self.machine_running = True
            self.open_screw_machine.setText("停止螺丝机")
            self.start_detection.setText("检测中")

    def toggle_screw_machine(self):
        if self.machine_running:
            if self.serial_tool.send_stop_run():
                self.machine_running = False
                self.open_screw_machine.setText("打开螺丝机")
                self.start_detection.setText("开始检测")
        else:
            if self.serial_tool.send_start_run():
                self.machine_running = True
                self.open_screw_machine.setText("停止螺丝机")

    def send_settings_to_lower(self, settings):
        if self.serial_tool.send_settings(settings):
            print("参数已按协议发送到下位机")

    def open_settings(self):
        if self.settings_window is None or not self.settings_window.isVisible():
            self.settings_window = SettingsWindow(self)
            self.settings_window.settings_changed.connect(self.send_settings_to_lower)
        self.settings_window.show()

    def open_torque_window(self):
        window = TorqueWindow(self)
        window.torque_selected.connect(self.serial_tool.send_torque)
        window.exec_()

    def open_speed_window(self):
        window = SpeedWindow(self)
        window.speed_selected.connect(self.serial_tool.send_speed)
        window.exec_()


    def closeEvent(self, event):
        print("程序正在关闭")

        # 断开串口
        if hasattr(self, 'serial_tool'):
            try:
                self.serial_tool.disconnect_serial()
                print("串口已断开")
            except Exception as e:
                print(f"断开串口时出错: {e}")

        # 关闭摄像头
        if hasattr(self, 'camera') and self.camera is not None:
            try:
                self.camera.close_camera()
                print("摄像头已关闭")
            except Exception as e:
                print(f"关闭摄像头时出错: {e}")
        else:
            print("摄像头未打开，跳过")

        print("程序已退出")
        event.accept()
