from PyQt5.QtWidgets import QDialog
from PyQt5.uic import loadUi
from PyQt5.QtCore import pyqtSignal


class TorqueWindow(QDialog):
    torque_selected = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        loadUi("niuju_dangwei_chuangkou.ui", self)

        self.btn_gear1.clicked.connect(lambda: self.select_torque(1))
        self.btn_gear2.clicked.connect(lambda: self.select_torque(2))
        self.btn_gear3.clicked.connect(lambda: self.select_torque(3))
        self.btn_cancel_torque.clicked.connect(self.reject)

    def select_torque(self, level):
        self.torque_selected.emit(level)
        self.accept()
