import os
import glob
import json
import struct
from datetime import datetime
import serial
from serial.tools import list_ports
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QMessageBox

from protocol import LOWER_HEADER, UPPER_HEADER, build_frame, hex_text, pop_frame


DEFAULT_SETTINGS = {
    "image_height": 1280,
    "image_width": 720,
    "real_height": 26.48,
    "real_width": 15.75,
    "offset_height": 3.50,
    "offset_width": 3.59,
}


class SerialModule:
    def __init__(self, ui):
        self.ui = ui
        self.serial_connection = None
        self.receive_buffer = bytearray()
        self.handshake_ok = False

        self.read_timer = QTimer(self.ui)
        self.read_timer.setInterval(50)
        self.read_timer.timeout.connect(self.read_serial_data)

        self.handshake_timer = QTimer(self.ui)
        self.handshake_timer.setInterval(3000)
        self.handshake_timer.timeout.connect(self.send_handshake)

    def refresh_serial_ports(self):
        self.ui.comboBox_serialPort.clear()
        found_ports = []

        for port in list_ports.comports():
            if port.device not in found_ports:
                found_ports.append(port.device)

        patterns = ["/dev/ttyS*", "/dev/ttyUSB*", "/dev/ttyACM*"]
        for pattern in patterns:
            for device in glob.glob(pattern):
                if device not in found_ports and self._is_port_available(device):
                    found_ports.append(device)

        if found_ports:
            for device in found_ports:
                self.ui.comboBox_serialPort.addItem(device, device)

            self.ui.comboBox_serialPort.setCurrentIndex(0)
            print(f"检测到 {len(found_ports)} 个串口:")
            for device in found_ports:
                print(f"   {device}")
        else:
            self.ui.comboBox_serialPort.addItem("未找到串口")
            print("未检测到任何串口")

    def _is_port_available(self, device):
        try:
            fd = os.open(device, os.O_RDWR | os.O_NONBLOCK)
            os.close(fd)
            return True
        except:
            return False

    def connect_serial(self):
        current_index = self.ui.comboBox_serialPort.currentIndex()
        if current_index < 0:
            QMessageBox.warning(self.ui, "提示", "请先选择串口")
            return False

        port_path = self.ui.comboBox_serialPort.itemData(current_index)
        if not port_path:
            QMessageBox.warning(self.ui, "提示", "无效的串口路径")
            return False

        if self.serial_connection and self.serial_connection.is_open:
            self.disconnect_serial()
            return True

        try:
            ser = serial.Serial(port=port_path, baudrate=115200, timeout=0, write_timeout=1)
            self.serial_connection = ser
            self.receive_buffer.clear()
            self.handshake_ok = False
            self.read_timer.start()
            self.handshake_timer.start()
            self._set_connection_text("等待握手", "color: orange;")
            self._set_device_status("设备状态：串口已打开，等待握手")
            print(f"串口 {port_path} 连接成功")
            self.send_handshake()
            return True

        except serial.SerialException as e:
            QMessageBox.critical(self.ui, "连接失败", f"串口连接失败！\n错误信息：{e}")
            print(f"串口连接失败: {e}")
            return False

    def disconnect_serial(self):
        self.read_timer.stop()
        self.handshake_timer.stop()
        self.handshake_ok = False
        self.receive_buffer.clear()

        if self.serial_connection and self.serial_connection.is_open:
            self.serial_connection.close()
            self.serial_connection = None
            self._set_connection_text("连接", "")
            self._set_device_status("设备状态：未连接")
            print("已断开串口连接")

    def is_connected(self):
        return self.serial_connection is not None and self.serial_connection.is_open

    def is_handshake_ok(self):
        return self.is_connected() and self.handshake_ok

    def send_handshake(self):
        if not self.is_connected() or self.handshake_ok:
            return False
        return self._write_frame(0x02, b"\x01", "握手请求")

    def send_coordinate(self, x, y):
        if not self._check_ready():
            return False

        x = max(0, min(int(x), 0xFFFF))
        y = max(0, min(int(y), 0xFFFF))
        data = x.to_bytes(2, byteorder="big") + y.to_bytes(2, byteorder="big")
        return self._write_frame(0x01, data, f"发送坐标 x={x}, y={y}")

    def send_start_run(self):
        if not self._check_ready():
            return False
        self._set_device_status("设备状态：已连接，开始运行")
        return self._write_frame(0x00, b"\x01", "开始运行")

    def send_stop_run(self):
        if not self._check_ready():
            return False
        self._set_device_status("设备状态：已连接，停止运行")
        return self._write_frame(0x00, b"\x02", "停止运行")

    def send_speed(self, level):
        if not self._check_ready():
            return False

        level = int(level)
        command_map = {
            1: 0x18,
            2: 0x19,
            3: 0x20,
        }
        command = command_map.get(level)
        if command is None:
            QMessageBox.warning(self.ui, "提示", "速度档位无效")
            return False

        if hasattr(self.ui, "current_speed1"):
            self.ui.current_speed1.setText(str(level))
        return self._write_frame(command, bytes((level,)), f"速度档位 {level}")

    def send_torque(self, level):
        if not self._check_ready():
            return False

        level = int(level)
        if level not in (1, 2, 3):
            QMessageBox.warning(self.ui, "提示", "扭矩档位无效")
            return False

        if hasattr(self.ui, "current_torque1"):
            self.ui.current_torque1.setText(str(level))
        return self._write_frame(0x21, bytes((level,)), f"扭矩档位 {level}")

    def send_time_sync(self):
        if not self._check_ready():
            return False

        now = datetime.now()
        minute_of_day = now.hour * 60 + now.minute
        data = minute_of_day.to_bytes(2, byteorder="big")
        return self._write_frame(0x17, data, f"时间同步 {now:%H:%M}")

    def send_settings(self, settings):
        if not self._check_ready():
            return False

        ok = True
        ok = self.send_u16_config(0x11, settings["image_height"], "像素长度") and ok
        ok = self.send_u16_config(0x12, settings["image_width"], "像素宽度") and ok
        ok = self.send_float_config(0x13, settings["real_height"], "实际长度") and ok
        ok = self.send_float_config(0x14, settings["real_width"], "实际宽度") and ok
        ok = self.send_float_config(0x15, settings["offset_height"], "偏移长度") and ok
        ok = self.send_float_config(0x16, settings["offset_width"], "偏移宽度") and ok
        return ok

    def send_saved_settings(self):
        settings = dict(DEFAULT_SETTINGS)
        try:
            if os.path.exists("measure_config.json"):
                with open("measure_config.json", "r", encoding="utf-8") as f:
                    saved_settings = json.load(f)
                settings.update(saved_settings)
        except Exception as e:
            print(f"读取参数配置失败，使用默认参数: {e}")

        return self.send_settings(settings)

    def send_u16_config(self, command, value, note):
        if not self._check_ready():
            return False

        value = max(0, min(int(value), 0xFFFF))
        data = value.to_bytes(2, byteorder="big")
        return self._write_frame(command, data, f"{note}={value}")

    def send_float_config(self, command, value, note):
        if not self._check_ready():
            return False

        data = struct.pack(">f", float(value))
        return self._write_frame(command, data, f"{note}={float(value):.3f}")

    def _check_ready(self):
        if not self.is_connected():
            QMessageBox.warning(self.ui, "提示", "请先连接串口")
            return False
        if not self.handshake_ok:
            QMessageBox.warning(self.ui, "提示", "下位机尚未握手成功")
            return False
        return True

    def read_serial_data(self):
        if not self.is_connected():
            return

        try:
            size = self.serial_connection.in_waiting
            if size <= 0:
                return
            data = self.serial_connection.read(size)
        except serial.SerialException as e:
            print(f"读取串口失败: {e}")
            self.disconnect_serial()
            return

        if not data:
            return

        self.receive_buffer.extend(data)
        print(f"RX RAW: {hex_text(data)}")

        while True:
            frame = pop_frame(self.receive_buffer, (LOWER_HEADER,))
            if frame is None:
                break
            self._handle_frame(frame)

    def _handle_frame(self, frame):
        print(
            "RX FRAME: cmd=0x%02X data=%s"
            % (frame.command, hex_text(frame.data))
        )

        if frame.command == 0x02 and frame.data == b"\x01":
            self.handshake_ok = True
            self.handshake_timer.stop()
            self._set_connection_text("已连接", "color: green;")
            self._set_device_status("设备状态：已连接")
            print("下位机握手成功")
            return

        if frame.command == 0x01 and len(frame.data) == 1:
            if frame.data == b"\x01":
                self._set_device_status("设备状态：已连接，开始识别")
                if hasattr(self.ui, "request_coordinate_send_from_lower"):
                    QTimer.singleShot(0, self.ui.request_coordinate_send_from_lower)
            elif frame.data == b"\x02":
                self._set_device_status("设备状态：已连接，停止运行")
                if hasattr(self.ui, "on_lower_stop_requested"):
                    QTimer.singleShot(0, self.ui.on_lower_stop_requested)
            return

        if frame.command == 0x10 and frame.data == b"\x01":
            self._set_device_status("设备状态：已连接，下位机请求配置")
            QTimer.singleShot(0, self.send_saved_settings)
            return

        if frame.command == 0x03 and len(frame.data) == 4 and hasattr(self.ui, "current_number1"):
            value = int.from_bytes(frame.data, byteorder="big", signed=False)
            self.ui.current_number1.setText(str(value))
            return

        if frame.command == 0x04 and len(frame.data) == 1 and hasattr(self.ui, "current_torque1"):
            self.ui.current_torque1.setText(str(frame.data[0]))
            return

        if frame.command == 0x05 and len(frame.data) == 1 and hasattr(self.ui, "current_speed1"):
            self.ui.current_speed1.setText(str(frame.data[0]))
            return

    def _write_frame(self, command, data, note=""):
        if not self.is_connected():
            return False
        frame = build_frame(UPPER_HEADER, command, data)
        try:
            self.serial_connection.write(frame)
            self.serial_connection.flush()
            if note:
                print(f"TX {note}: {hex_text(frame)}")
            else:
                print(f"TX: {hex_text(frame)}")
            return True
        except serial.SerialException as e:
            QMessageBox.critical(self.ui, "发送失败", f"串口发送失败：{e}")
            print(f"串口发送失败: {e}")
            self.disconnect_serial()
            return False

    def _set_connection_text(self, text, style):
        if hasattr(self.ui, "pushButton_connect"):
            self.ui.pushButton_connect.setText(text)
            self.ui.pushButton_connect.setStyleSheet(style)

    def _set_device_status(self, text):
        if hasattr(self.ui, "devicestatus"):
            self.ui.devicestatus.setText(text)
